package UI;

import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import Data.Message;
import Data.MyFile;
import ToServer.ToServerThread;

public class GroupChatFrame extends JFrame{
	    JTextArea chatwords;
	    public static JTextArea chatrecord;
	    JButton expressionb,sendwordsb,hideb,sendfileb;
	    Font font=new Font("����", Font.BOLD, 15);
	    JFileChooser filechooser=new JFileChooser(".");


		public GroupChatFrame(){
        	//���ڻ�������
        	setSize(800, 600);
        	setLocationRelativeTo(null);
        	setUndecorated(true);
        	new LocationUtil(this);
        	try {
     			 Class clazz = Class.forName("com.sun.awt.AWTUtilities");
     			 Method method = clazz.getMethod("setWindowOpaque", java.awt.Window.class, Boolean.TYPE);    
     			 method.invoke(clazz, this, false); 
     		   } catch (Exception e) {
     			e.printStackTrace();
     		   }          
        	
     	   JLabel mainlabel=new JLabel(new ImageIcon(this.getClass().getResource("groupchatframebackround.png")));
     	  
     	  
		
     	   chatrecord=new JTextArea();
     	   chatrecord.setBackground(Color.white);
     	   JScrollPane chrsp=new JScrollPane(chatrecord);
     	   chrsp.setBorder(null);
     	  //�����¼�ı����ʼ��
     	   
     	   chatwords=new JTextArea();
     	   chatwords.setFont(font);
     	   JScrollPane chwsp=new JScrollPane(chatwords);
     	   chwsp.setBorder(null);//��Ϣ�����ı����ʼ��
     	   
     	   expressionb=new JButton(new ImageIcon(this.getClass().getResource("expressionb.png")));
     	   //���鰴ť
     	   
     	   sendfileb=new JButton(new ImageIcon(this.getClass().getResource("sendfileb.png")));
     	  sendfileb.addActionListener(new ActionListener() {
  			
  			@Override
  			public void actionPerformed(ActionEvent e) {
  				// TODO Auto-generated method stub
  				try {
  					
  				    filechooser.showOpenDialog(sendfileb);
  				    File selectedfile=filechooser.getSelectedFile();
  				    FileInputStream filein=new FileInputStream(selectedfile);
  				    byte[] b=new byte[filein.available()];
  				    filein.read(b);
  					MyFile sendedfile=new MyFile(b,selectedfile.getName(),InetAddress.getLocalHost());
  				    ToServerThread.toserver.writeObject(sendedfile);
  					chatrecord.append("Me:\n"+"  ���Ͳ����ļ�����鿴\n"
  							+selectedfile.getName()+"\n");
  					
  				} catch (UnknownHostException e1) {
  					// TODO Auto-generated catch block
  					e1.printStackTrace();
  				} catch (IOException e1) {
  					// TODO Auto-generated catch block
  					e1.printStackTrace();
  				}
  			}
  		});
    	   //�����ļ���ť��ʼ��
     	   
     	   sendwordsb=new JButton(new ImageIcon(this.getClass().getResource("sendwords.png")));
     	   
     	   new Thread(){

  			@Override
  			public void run() {
  				// TODO Auto-generated method stub
  				while(true){
  				if(chatwords.getText().equals("")){sendwordsb.setEnabled(false);}
  				else{sendwordsb.setEnabled(true);}
  				try {
  					sleep(10);
  				} catch (InterruptedException e) {
  					// TODO Auto-generated catch block
  					e.printStackTrace();
  				}
  				}
  			}}.start();
  			
  			sendwordsb.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					try {
					String textsended=chatwords.getText();
					Message messagesended;
					messagesended = new Message(textsended,InetAddress.getLocalHost());
					chatrecord.append("Me:\n"+textsended+"\n");
					ToServerThread.toserver.writeObject(messagesended);
					
					chatwords.setText("");
					} catch (UnknownHostException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
     	    //���Ͱ�ť��ʼ��
     	   
     	   hideb=new JButton(new ImageIcon(this.getClass().getResource("hideb.png")));
     	   hideb.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			     setVisible(false);
			}
		});
     	   //���ش��ڰ�ť��ʼ��
     	   
     	   mainlabel.add(chrsp);
     	   mainlabel.add(chwsp);
     	   mainlabel.add(expressionb);
     	   mainlabel.add(sendfileb);
     	   mainlabel.add(sendwordsb);
     	   mainlabel.add(hideb);
     	   chrsp.setBounds(160,110,400,250);
     	   chwsp.setBounds(160,400,400,80);
     	   expressionb.setBounds(460,360,30,30);
     	   sendfileb.setBounds(520, 360, 30, 30);
     	   sendwordsb.setBounds(480,490,60,40);
     	   hideb.setBounds(new Rectangle(750,0,50,50));
     	  
     	   
     	   this.add(mainlabel);
        }
        
        
//        public static void main(String[] args) {
//		    GroupChatFrame frame=new GroupChatFrame();
//			frame.setVisible(true);
//		}//����
}