package Data;

import java.io.Serializable;
import java.net.InetAddress;

public class MyFile implements Serializable{
        public byte[] filecontent;
        public String filename;
        public InetAddress IP;
        public InetAddress MyIP;
        boolean flag=false;//falseΪȺ�ģ�trueΪ˽��
        
        public MyFile(byte[] con,String name,InetAddress ip,InetAddress myip){
        	filecontent=con;
        	filename=name;
        	IP=ip;
        	MyIP=myip;
        	flag=true;
        }
        
        public MyFile(byte[] con,String name,InetAddress myip){
        	filecontent=con;
        	filename=name;
        	MyIP=myip;
        }
        
        public boolean getmode(){
        	return flag;
        }
}
