package Data;

import java.io.Serializable;
import java.net.InetAddress;

public class Message implements Serializable{
     public String s;
     public InetAddress IP;
     public InetAddress MyIP;
     boolean flag=false;
     
     public Message(String m,InetAddress ip,InetAddress myip){
    	   s=m;
    	   IP=ip;
    	   MyIP=myip;
    	   flag=true;
     }
     
     public Message(String m,InetAddress myip){
    	 s=m;
    	 MyIP=myip;
     }
     
     public boolean getmode(){
    	 return flag;
     }
}
