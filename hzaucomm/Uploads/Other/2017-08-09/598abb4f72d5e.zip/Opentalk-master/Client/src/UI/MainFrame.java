package UI;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.lang.reflect.Method;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

import Data.DataMemory;
import ToServer.ToServerThread;


public class MainFrame extends JFrame{
	   JButton groupchat;
	   static public JList friendlist;
	   static public JOptionPane showerror=new JOptionPane();
	   static public DefaultListModel listmodel=new DefaultListModel();
	   static public GroupChatFrame groupchatframe=new GroupChatFrame();
	   
       public MainFrame(){
    	   
    	   
    	   //���ڻ�������
    	   
    	   Dimension srcsize=Toolkit.getDefaultToolkit().getScreenSize();
    	   this.setLocation(srcsize.width-400,srcsize.height-750);
    	   this.setSize(300, 700);
    	   this.setUndecorated(true);
    	   new LocationUtil(this);//ʹ�ô��ڿ��Ը�������ƶ�
    	   try {
  			 Class clazz = Class.forName("com.sun.awt.AWTUtilities");
  			 Method method = clazz.getMethod("setWindowOpaque", java.awt.Window.class, Boolean.TYPE);    
  			 method.invoke(clazz, this, false); 
  		   } catch (Exception e) {
  			e.printStackTrace();
  		   }//����͸����          

    	   JLabel mainlabel=new JLabel(new ImageIcon(this.getClass().getResource("clientmainbackround.png")));
  		  
  		  friendlist=new JList(listmodel);
  		  JScrollPane fsp=new JScrollPane(friendlist);
  		  friendlist.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				if(e.getClickCount()==2){
					int m=friendlist.locationToIndex(e.getPoint());
					if(m!=-1){
						int n=DataMemory.CheckExistedFrame(DataMemory.AllClient.get(m));
						if(n!=-1){//�ô����Ѵ���
							DataMemory.AllChatFrame.get(n).setVisible(true);
						}else{//�����в����ڣ����½�һ������
							ChatFrame newframe=new ChatFrame(DataMemory.AllClient.get(m).IP);
							DataMemory.AllChatFrame.add(newframe);
							newframe.setVisible(true);
						}
					}
				}
			}
  			  
		});
  		  //�����б���ʼ��
  		  
  		  groupchat=new JButton(new ImageIcon(this.getClass().getResource("groupchat.png")));
  		  groupchat.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				groupchatframe.setVisible(true);
			}
		});//Ⱥ�İ�ť��ʼ��
  		  
  		  JButton exitb=new JButton(new ImageIcon(this.getClass().getResource("mainexit.png")));
  		  exitb.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			   String s="Bye";
			   try {
				ToServerThread.toserver.writeObject(s);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			}
		});//�رհ�ť��ʼ��
  		
  		  mainlabel.setOpaque(false);
  		  mainlabel.setLayout(null);
  		  mainlabel.add(fsp);
  		  mainlabel.add(groupchat);
  		  mainlabel.add(exitb);
  		  fsp.setBounds(60,80, 180, 390);
  		  groupchat.setBounds(80,570, 140, 40);
  		  exitb.setBounds(250,650, 50, 50);
  		  this.add(mainlabel);
  		  
  		  
  		  
  		
  		
  
       }
       
       /*public static void main(String[] args) {
		   MainFrame frame=new MainFrame();
	  	   frame.setVisible(true);
	  }//����*/
}
