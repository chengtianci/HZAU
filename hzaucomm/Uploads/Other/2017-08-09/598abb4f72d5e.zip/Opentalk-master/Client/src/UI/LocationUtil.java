package UI;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.lang.reflect.Method;

import javax.swing.JFrame;

public class LocationUtil {
	JFrame fram;
	private int xx, yy;
	private boolean isDraging = false;
   
	public LocationUtil(JFrame frame) {
		this.fram = frame;
		fram.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				isDraging = true;
				xx = e.getX();
				yy = e.getY();
			}

			public void mouseReleased(MouseEvent e) {

				isDraging = false;
			}
		});
		fram.addMouseMotionListener(new MouseMotionAdapter() {
			public void mouseDragged(MouseEvent e) {
				if (isDraging) {
					int left =fram.getLocation().x;
					int top = fram.getLocation().y;
					fram.setLocation(left + e.getX() - xx, top + e.getY() - yy);
				}
			}
		});
	}
	public void setOp(){
		try {
			Class clazz = Class.forName("com.sun.awt.AWTUtilities");
			Method method = clazz.getMethod("setWindowOpaque",
					java.awt.Window.class, Boolean.TYPE);
			method.invoke(clazz, fram, false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
