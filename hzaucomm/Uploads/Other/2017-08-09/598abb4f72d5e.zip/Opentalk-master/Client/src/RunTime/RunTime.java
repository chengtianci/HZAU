package RunTime;

import ToServer.ToServerThread;
import UI.MainFrame;

public class RunTime {
	
     public static void main(String[] args) {
		

    	new ToServerThread();
		MainFrame mainframe=new MainFrame();
	    mainframe.setVisible(true);
}
}
