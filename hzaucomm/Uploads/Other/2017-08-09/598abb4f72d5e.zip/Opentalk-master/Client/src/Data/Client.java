package Data;

import java.io.Serializable;
import java.net.InetAddress;

public class Client implements Serializable{
        public InetAddress IP;
        public int port;
        
        public Client(InetAddress ip,int p){
        	IP=ip;
        	port=p;
        }
}
