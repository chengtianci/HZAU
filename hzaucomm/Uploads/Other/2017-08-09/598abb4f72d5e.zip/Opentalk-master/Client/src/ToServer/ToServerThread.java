package ToServer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Vector;

import javax.swing.JOptionPane;

import Data.Client;
import Data.DataMemory;
import Data.Message;
import Data.MyFile;
import UI.ChatFrame;
import UI.MainFrame;

public class ToServerThread extends Thread {
	InetAddress host = null;
	Socket aboutserver;
	ObjectInputStream fromserver;
	public static ObjectOutputStream toserver;

	public ToServerThread() {
		try {

			host = InetAddress.getByName("10.245.172.211");
			aboutserver = new Socket(host, 2333);
			toserver = new ObjectOutputStream(aboutserver.getOutputStream());
			// �������������Ӳ��Ҵ��������

			fromserver = new ObjectInputStream(aboutserver.getInputStream());
			try {
				DataMemory.AllClient = (Vector<Client>) fromserver.readObject();
				DataMemory.ShowClient(DataMemory.AllClient);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}// ��ȡ�û��б�

			Client me = new Client(InetAddress.getLocalHost(), 2333);
			toserver.writeObject(me);
			// ��������ַ��Ϣ���͸�������

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			MainFrame.showerror.showMessageDialog(null, "���ӷ�����ʧ��", "����",
					JOptionPane.ERROR_MESSAGE);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			MainFrame.showerror.showMessageDialog(null, "���ӷ�����ʧ��", "����",
					JOptionPane.ERROR_MESSAGE);
		}

		start();
	}

	public void run() {
		

			while (true) {
				try {
					
					
				Object f = fromserver.readObject();
                
				
				if (f instanceof Message) {
					Message message = (Message) f;
					if (!message.getmode()) {// Ⱥ����Ϣ
						if(!message.MyIP.getHostAddress()
								.equals(InetAddress.getLocalHost().getHostAddress())){
						MainFrame.groupchatframe.chatrecord.append(DataMemory
								.ToString(message));
						}
					} else {// ˽����Ϣ
						int n = DataMemory.CheckExistedFrame(message);
						if (n == -1) {// ����˽�Ĵ�����δ����
							ChatFrame newframe = new ChatFrame(message.MyIP);
							newframe.chatrecord.append(DataMemory
									.ToString(message));
							DataMemory.AllChatFrame.add(newframe);
							newframe.setVisible(true);
						} else {// ����˽�Ĵ����ѱ�����
							DataMemory.AllChatFrame.get(n).chatrecord
									.append(DataMemory.ToString(message));
							DataMemory.AllChatFrame.get(n).setVisible(true);
						}
					}
				}

				if (f instanceof String) {// ���յ����ߵ���Ϣ�Զ��˳�
					toserver.writeObject(new String("Bye"));
					break;
				}

				if (f instanceof Client) {// �������û�
					DataMemory.addClient((Client) f);
				}

				if (f instanceof InetAddress) {// �޳�һ���û�
					int m;
					String s = ((InetAddress) f).getHostAddress();
					
					for (m = 0; m < DataMemory.AllClient.size(); m++) {
						if (DataMemory.AllClient.get(m).IP.getHostAddress()
								.equals(s))
							break;
					}
					if(m<DataMemory.AllClient.size()){
						DataMemory.AllClient.remove(m);
						MainFrame.listmodel.remove(m);
					}
					
					for(m=0;m<DataMemory.AllChatFrame.size();m++){
					    if(DataMemory.AllChatFrame.get(m).
					    		ip.getHostAddress().equals(s))
					    	break;	
					}
					
					if(m<DataMemory.AllChatFrame.size()){
					   DataMemory.AllChatFrame.get(m).dispose();
					   DataMemory.AllChatFrame.remove(m);
					}
				}
				
				if(f instanceof MyFile){
					
					MyFile myfile=(MyFile)f;
					File newfile=new File("./"+myfile.filename);
					FileOutputStream filesave=new FileOutputStream(newfile);
					filesave.write(myfile.filecontent);
					filesave.close();
					if(!myfile.getmode()){//Ⱥ���ļ�
						if(!myfile.MyIP.getHostAddress()
								.equals(InetAddress.getLocalHost().getHostAddress())){
						MainFrame.groupchatframe.chatrecord.append(DataMemory
								.ToString(myfile));
						}
					}else{//˽���ļ�
						int n = DataMemory.CheckExistedFrame(myfile);
						if (n == -1) {// ����˽�Ĵ�����δ����
							ChatFrame newframe = new ChatFrame(myfile.MyIP);
							newframe.chatrecord.append(DataMemory
									.ToString(myfile));
							newframe.setVisible(true);
							DataMemory.AllChatFrame.add(newframe);
						} else {// ����˽�Ĵ����ѱ�����
							DataMemory.AllChatFrame.get(n).chatrecord
									.append(DataMemory.ToString(myfile));
							DataMemory.AllChatFrame.get(n).setVisible(true);
						}
					}
					
				}


				} catch (IOException e) {
					// TODO Auto-generated catch block
					MainFrame.showerror.showMessageDialog(null, "���ӷ�����ʧ��", "����",
							JOptionPane.ERROR_MESSAGE);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			System.exit(0);
		
	}
}
