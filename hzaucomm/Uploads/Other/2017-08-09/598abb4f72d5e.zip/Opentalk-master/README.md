# Opentalk
很久以前刚学java时写的基于Swing的C/S结构的聊天程序，Bug层出不穷，现在看来结构好乱。。。。
