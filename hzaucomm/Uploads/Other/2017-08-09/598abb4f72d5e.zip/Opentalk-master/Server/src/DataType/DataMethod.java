package DataType;

import Data.Client;
import Data.Message;
import UI.MainFrame;

public class DataMethod {
	static public void addclient(Client newclient){
    	String s=newclient.IP+"  "+newclient.port;
    	MainFrame.ClientNow.addElement(newclient);
    	MainFrame.clientlistmodel.addElement(s);
    }
	
	 public static String ToString(Message message){
    	 String result=message.MyIP.getHostAddress()+":\n"+message.s+"\n";
    	 return result;
     }
}
