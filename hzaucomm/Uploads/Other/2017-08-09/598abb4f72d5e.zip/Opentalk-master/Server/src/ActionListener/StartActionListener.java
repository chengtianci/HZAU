package ActionListener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.ServerSocket;

import javax.swing.JOptionPane;

import UI.MainFrame;

public class StartActionListener implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		try {

			ServerSocket serversocket = new ServerSocket(2333);
			new ServerThreadF(serversocket);
			MainFrame.startb.setEnabled(false);

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		MainFrame.dialog.showMessageDialog(MainFrame.startb, "�����ɹ�", "OK",
				JOptionPane.INFORMATION_MESSAGE);
	}

}
