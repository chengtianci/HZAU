package ActionListener;

import java.io.IOException;
import java.io.ObjectInputStream;

import Data.Client;
import Data.Message;
import Data.MyFile;
import UI.MainFrame;


public class InputDisposeThread extends Thread{
	public ObjectInputStream fromclients;
    Client client;

	public InputDisposeThread(ObjectInputStream instream,Client inclient){
		fromclients = instream;
		client=inclient;
		start();
	}

	@Override
	public void run(){
		// TODO Auto-generated method stub
		try {
		while (true) {
			

				Object newOb = fromclients.readObject();

				if (newOb instanceof Message) {
					Message newmessage = (Message) newOb;
					if (!newmessage.getmode()) {//Ⱥ����Ϣ
						for (int i = 0; i < ServerThreadF.outputstreams.size(); i++) {
							ServerThreadF.outputstreams.get(i).writeObject(
									newmessage);
						}
					} else {//˽����Ϣ
						int m;
						for (m = 0; m < MainFrame.ClientNow.size(); m++) {
							if (MainFrame.ClientNow.get(m).IP.getHostAddress()
									.equals(newmessage.IP.getHostAddress())) break;
						}
						if(m<MainFrame.ClientNow.size())
							ServerThreadF.outputstreams.get(m).writeObject(newmessage);
					}
				}
				
				if(newOb instanceof String){//�ӵ��ͻ����˳���Ϣ
				   int m=MainFrame.ClientNow.indexOf(client);
				   MainFrame.ClientNow.remove(m);
				   MainFrame.clientlistmodel.remove(m);
				   ServerThreadF.outputstreams.remove(m);
				   for(int i=0;i<ServerThreadF.outputstreams.size();i++){
					   ServerThreadF.outputstreams.get(i).writeObject(client.IP);
				   }
				   break;
				}
				
				if(newOb instanceof MyFile){
					
				   MyFile myfile=(MyFile)newOb;
				   if(!myfile.getmode()){//Ⱥ���ļ�
					   for (int i = 0; i < ServerThreadF.outputstreams.size(); i++) {
							ServerThreadF.outputstreams.get(i).writeObject(
									myfile);
						}
				   }else{//˽���ļ�
					   int m;
						for (m = 0; m < MainFrame.ClientNow.size(); m++) {
							if (MainFrame.ClientNow.get(m).IP.getHostAddress()
									.equals(myfile.IP.getHostAddress())) break;
						}
						if(m<MainFrame.ClientNow.size())
							ServerThreadF.outputstreams.get(m).writeObject(myfile);
				   }
				   
				}

			}
		    }catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}
}


