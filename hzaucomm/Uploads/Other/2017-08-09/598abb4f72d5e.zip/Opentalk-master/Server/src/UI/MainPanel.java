package UI;

import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class MainPanel extends JPanel{
       public void paintComponent(Graphics g){
    	   ImageIcon backround=new ImageIcon(this.getClass().getResource("serverbackround.jpg"));
    	   g.drawImage(backround.getImage(), 0, 0, 415, 330, this);
       }
}
