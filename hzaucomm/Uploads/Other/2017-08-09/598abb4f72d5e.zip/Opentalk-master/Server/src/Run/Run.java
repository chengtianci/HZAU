package Run;


import UI.MainFrame;

public class Run {
	  
	
      public static void main(String[] args) {
   
			
			
	
			MainFrame mainframe=new MainFrame();
			mainframe.setVisible(true);
			
			
		
	}
}
