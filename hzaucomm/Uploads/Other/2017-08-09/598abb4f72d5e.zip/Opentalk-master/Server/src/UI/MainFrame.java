package UI;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

import ActionListener.ServerThreadF;
import ActionListener.StartActionListener;
import Data.Client;

public class MainFrame extends JFrame{
      static public JList clientlist;
      static public DefaultListModel clientlistmodel;
      static public JButton kickb,startb,stopb;
      static public JOptionPane dialog=new JOptionPane();
      static public Vector<Client> ClientNow=new Vector(10,10);
      MainPanel mainpanel=new MainPanel();
      
      public MainFrame(){
    	  this.setSize(415, 330);
    	  this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	  this.setLocationRelativeTo(null);
    	  this.setUndecorated(true);
    	  new LocationUtil(this);
    	  //���ڵ���
          
    	  clientlistmodel=new DefaultListModel();
    	  clientlist=new JList(clientlistmodel);
    	  JScrollPane clmsp=new JScrollPane(clientlist);//���ӿͻ��б���ʼ��
    	  
    	  ImageIcon logoicon=new ImageIcon(this.getClass().getResource("ServerLogo.png"));
    	  JLabel logolabel=new JLabel(logoicon);//logoͼƬ��ʼ��
    	 
    	  ImageIcon tirenicon=new ImageIcon(this.getClass().getResource("tiren.png"));
    	  kickb=new JButton(tirenicon);
    	  kickb.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int m=clientlist.getSelectedIndex();
				if(m!=-1){
					try {
						ServerThreadF.outputstreams.get(m).writeObject(new String("Bye"));
					    MainFrame.dialog.showMessageDialog(MainFrame.kickb, "���˳ɹ�", "OK",
									JOptionPane.INFORMATION_MESSAGE);
						
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});//���˰�ť
    	  
    	  ImageIcon qidongicon=new ImageIcon(this.getClass().getResource("qidong.png"));
    	  startb=new JButton(qidongicon);
    	  startb.addActionListener(new StartActionListener());
    	  
    	  ImageIcon guanbiicon=new ImageIcon(this.getClass().getResource("guanbi.png"));
    	  stopb=new JButton(guanbiicon);
    	  stopb.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			           System.exit(0);	
			}
		});
    	  //���ˡ��������رհ�ť��ʼ��
    	  
    	 
    	  
    	 
    	  mainpanel.setLayout(null);
    	  mainpanel.add(clmsp);
    	  mainpanel.add(logolabel);
    	  mainpanel.add(kickb);
    	  mainpanel.add(startb);
    	  mainpanel.add(stopb);
    	  logolabel.setBounds(0, 0, 100, 200);
    	  clmsp.setBounds(140, 40, 200, 150);
    	  kickb.setBounds(20,230,70,40);
    	  startb.setBounds(160,230,70,40);
    	  stopb.setBounds(250,230,70,40);
    	  this.add(mainpanel);
      }
      
    
}
