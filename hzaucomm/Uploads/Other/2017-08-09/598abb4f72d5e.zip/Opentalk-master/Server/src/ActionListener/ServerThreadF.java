package ActionListener;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;


import UI.MainFrame;

import Data.Client;
import DataType.DataMethod;

public class ServerThreadF extends Thread {
	Socket fromclient;
	ServerSocket serversocket;
	static public Vector<ObjectOutputStream> outputstreams=new Vector<ObjectOutputStream>(10,10);

	public ServerThreadF(ServerSocket inserversocket) {
		serversocket = inserversocket;
		start();
	}

	public void run() {
		while (true) {

			try {

				fromclient = serversocket.accept();
				
				
				ObjectInputStream input = new ObjectInputStream(fromclient
						.getInputStream());
				ObjectOutputStream output=new ObjectOutputStream(fromclient.getOutputStream());
				output.writeObject(MainFrame.ClientNow);//�������û��б�������ͻ���
				
				outputstreams.add(output);//����������������Ӹÿͻ��������
				
				Object newclient = input.readObject();
				DataMethod.addclient((Client)newclient);
				for(int i=0;i<outputstreams.size();i++){
					outputstreams.get(i).writeObject(newclient);
				}
				
				new InputDisposeThread(input,(Client)newclient);//�����������з�������
				



			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
}
