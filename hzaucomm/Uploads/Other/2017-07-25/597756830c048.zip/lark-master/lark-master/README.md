#名称：设备预约系统（Device Reserve）
-----------------------------------
##描述
用于实验室的设备网上预约。

----------------------------------
##功能
####前台：
- 注册登录，会话超时控制
- 根据日期查看预约情况
- 查看我的历史预约
- 查看成员的联系方式
- 公告板
- 修改资料

####后台：
- 添加设备，删除设备
- 设置预约时间规则（可预约时间段和没人每周最大预约次数）
- 用户管理
- 权限管理
- 公告管理
- 参数设置
- 查询功能

##主要引用
- MVC框架：[Thinkphp3.2](http://document.thinkphp.cn/manual_3_2.html)
- CSS：[Bootstrap](http://www.bootcss.com/)
- 注册表单：[RegistrationForm](https://github.com/simfatic/RegistrationForm)
- 日历控件：[Tigra Calendar](http://www.softcomplex.com/products/tigra_calendar/)

##示例
#### 首页/预约状态：
![首页/预约状态](http://raw.github.com/irgb/lark/master/demo/reserve-status.PNG)

-------------------------------------------
#### 预约设备
![预约设备](http://raw.github.com/irgb/lark/master/demo/reserve-device.PNG)

-------------------------------------------
####添加设备
![添加设备](http://raw.github.com/irgb/lark/master/demo/add-device.PNG)

-------------------------------------------
#### 权限管理
![权限管理](http://raw.github.com/irgb/lark/master/demo/permission-manage.PNG)

----------------------------------
#### 注册
![注册表单](http://raw.github.com/irgb/lark/master/demo/register.PNG)

----------------------------------
#### 登陆
![登陆表单](http://raw.github.com/irgb/lark/master/demo/login.PNG)

----------------------------------

##备注
>初学前端开发，不周之处敬请指导。  
>所有功能经过测试，没有发现明显bug，但并不代表没有。