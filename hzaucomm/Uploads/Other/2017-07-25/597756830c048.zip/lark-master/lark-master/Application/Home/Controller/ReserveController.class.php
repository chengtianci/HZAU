<?php
namespace Home\Controller;
use Think\Controller;
class ReserveController extends Controller{
	public function index()
	{
		$this->redirect('Reserve/home');
	}
	/*
	首页默认展示今天的预约状态
	 */
	public function home()
	{
		$show_date=date('Y-m-d');
		if(I('get.date'))
		{
			if(strtotime(I('get.date')))
				$show_date=I('get.date');
		}
		$device_table=M('device');
		$device_list=$device_table->order('id')->select();

		$user_table=M('user');
		$reservelog=M('reservelog');
		
		$condition['date']=$show_date;
		
		foreach($device_list as $key=>$value)
		{
			$device_id=$value['id'];
			$rules=preg_split('/,\s*/',$value['rules']);
			$device_list[$key]['reserveby']='';
			foreach($rules as $period)
			{
				$condition['device_id']=$device_id;
				$condition['period']=$period;
				$result=$reservelog->where($condition)->find();
				if($result)
				{
					$username=$result['username'];
					$realname=$user_table->where('username="'.$username.'"')->getField('realname');
					$device_list[$key]['reserveby']=$device_list[$key]['reserveby'].$realname.',';
				}else
				{
					$device_list[$key]['reserveby']=$device_list[$key]['reserveby'].'0,';
				}
			}
			if(strlen($device_list[$key]['reserveby'])>=1)
				$device_list[$key]['reserveby']= substr($device_list[$key]['reserveby'],0,strlen($device_list[$key]['reserveby'])-1);
		}

		//获取公告列表
		$m=M('bulletin');
		$m->table('__BULLETIN__ bulletin')->join('LEFT JOIN __USER__ user ON user.username = bulletin.username')->field('bulletin.id as id , bulletin.username as username ,bulletin.content as content , bulletin.createtime as createtime , user.realname as realname');
		$bulletin_list=$m->limit(5)->order('createtime desc')->select();

		$this->bulletin_list=$bulletin_list;
		$this->show_date=$show_date;
		$this->device_list=$device_list;
		$this->title='首页';
		$this->display();
	}
	/*
	显示预定页面
	 */
	public function reserve()
	{
		if(!session('?valid_user'))
		{
			$this->redirect('Member/login_form');
		}
		$device_table=M('device');
		$device_list=$device_table->order('id')->select();
		//创建date_list（包含下周的列表和本周剩余的列表）
		$date_list=getDate_list();
		$this->device_list=$device_list;
		$this->date_list=$date_list;
		$this->title='预约设备';
		$this->display();
	}
	/*
	记录预约
	 */
	public function record()
	{
		if(!session('?valid_user'))
		{
			$this->redirect('Member/login_form');
		}
		if(!IS_POST)
		{
			$this->redirect('Reserve/reserve');
		}
		$select_device=I('post.select_device');
		$select_date=I('post.select_date');
		$select_period=I('post.select_period');

		//检查是否有预约权限,新用户默认没有预约权限
		$condition['device_id']=$select_device;
		$condition['username']=session('valid_user');
		$condition['status']=1;
		$permission_table=M('permission');
		$result=$permission_table->where($condition)->find();
		if(!$result)
		{
			alert('ERROR','你没有此设备的预约权限！请联系管理员进行授权。');
			exit;
		}
		//检查表单是否填写完整
		if($select_device<=0)
		{
			alert('ERROR','请选择设备！');
			exit;
		}else if($select_date==0)
		{
			alert('ERROR','请选择日期！');
			exit;
		}
		else if($select_period==0)
		{
			alert('ERROR','请选择时间段！');
			exit;
		}
		$device_table=M('device');
		unset($condition);
		$condition['id']=$select_device;
		$device=$device_table->where($condition)->find();
		//判断要预约的设备是否存在
		if(!$device)
		{
			alert('ERROR','id='.$select_device.' 的设备不存在！');
			exit;
		}
		//判断是否禁止预约
		$limit_count=$device['limit_count'];
		if($limit_count==0)
		{
			$this->error('禁止预约!<br/>'
				.'设备名称:'.$device['name'].'<br/>');
		}
		//判断日期是否有效
		$today_timestamp=strtotime(date("Y-m-d"));

		$select_timestamp=strtotime($select_date);
		if($select_timestamp < strtotime('+1 day',$today_timestamp))
		{
			alert('ERROR','今天只能预约明天及以后的！');
			exit;
		}
		if(date("w",$select_timestamp)==0 && C('IS_SUNDAY_AVAILABLE')==false)//如果选择的日期是周日
		{
			alert('ERROR','周日禁止预约！');
			exit;
		}
		$next_week=strtotime("next week Monday");
		if($select_timestamp>=$next_week)
		{
			if(time()<getStartTime())
			{
				$this->error('下周预约尚未开始!<br/>'
				.'开始时间:'.date('Y-m-d H:i:s',getStartTime()).'<br/>'
				.'现在时间:'.date('Y-m-d H:i:s',time()).'<br/>');
			}
		}

		//判断是否达到预约次数(此处还没有加入一周之内的预约次数)
		$from =strtotime('Monday this week',strtotime($select_date));
		$to=strtotime('+6 day',$from);
		$from_date=date('Y-m-d',$from);
		$to_date=date('Y-m-d',$to);

		$reservelog=M('reservelog');
		unset($condition);
		$condition['device_id']=$select_device;
		$condition['username']=session('valid_user');
		$condition['date']=array('between',array($from_date,$to_date));
		$count=$reservelog->where($condition)->count();
		if($limit_count>0 && $count>=$limit_count)
		{
			$this->error('你在本周('.$from_date.'至'.$to_date.')'
				.'的预约次数已经达到限制!<br/>'
				.'设备名称:'.$device['name'].'<br/>'
				.'预约限制:'.$limit_count.'次/周<br/>'
				.'你已预约:'.$count.'次<br/>','','',100);
		}
		
		//判断时间段是否有效
		$rules=preg_split('/,\s*/',$device['rules']);
		if(!in_array($select_period,$rules))
		{
			alert('ERROR','时间段'.$select_period.' 不在规定范围内!');
			exit;
		}
		//判断是否已经被预约
		unset($condition);
		$condition['device_id']=$select_device;
		$condition['date']=$select_date;
		$condition['period']=$select_period;
		$result=$reservelog->where($condition)->find();
		if($result)
		{
			$this->error('日期:'.$result['date'].' ('.getWeek($result['date']).')<br/>'
				.'时间段:'.$result['period'].'<br/>'
				.'已经被<'.getRealName($result['username']).'>预约.');
		}
		//写入预约数据库
		$data['username']=session('valid_user');
		$data['device_id']=$select_device;
		$data['date']=$select_date;
		$data['period']=$select_period;
		$result=$reservelog->add($data);
		if($result)
		{
			$this->success('预定成功');
		}else
		{
			alert('ERROR','预定失败，请稍后再试!');
			exit;
		}
	}
	/*
	查询用户的预约记录
	 */
	public function myReserve()
	{
		if(!session('?valid_user'))
		{
			$this->redirect('Member/login_form');
		}
		$from_date='';
		$to_date='';
		if(I('get.from_date') && I('get.to_date'))
		{
			if(strtotime(I('get.from_date')))
				$from_date=I('get.from_date');
			if(strtotime(I('get.to_date')))
				$to_date=I('get.to_date');
		}
		if(strtotime($from_date)>strtotime($to_date))
		{
			alert('ERROR','起始日期不能晚于结束日期, 请重新选择');
			exit;
		}
		if(empty($from_date)||empty($to_date))
		{
			$from_timestamp=strtotime('Monday this week');
			$to_timestamp=strtotime('+6 day',$from_timestamp);
			$from_date=date('Y-m-d',$from_timestamp);
			$to_date=date('Y-m-d',$to_timestamp);
		}
		//查询
		$where=array();
		$where['reservelog.username']=session('valid_user');
		if(!empty($from_date) && !empty($to_date))
		{
			$where['date']=array('between',array($from_date,$to_date));
		}
		$m=M('reservelog');
		$m->table('__RESERVELOG__ reservelog')->join('LEFT JOIN __USER__ user ON user.username = reservelog.username')
		->join('LEFT JOIN __DEVICE__ device ON device.id = reservelog.device_id')
		->field('reservelog.id as id , reservelog.username as username , reservelog.period as period ,reservelog.date as date , user.realname as realname , device.name as device_name');
		$p=getpage($m,$where);
		$page=$p->show();
		$nowPage=intval(I('get.p'));
		if($nowPage>intval($p->totalPages))
		{
			$this->redirect('Reserve/myReserve',array('p'=>$totalPages));
		}
		$reserve_log_list=$m->where($where)->select();

		$this->reserve_log_list=$reserve_log_list;
		$this->from_date=$from_date;
		$this->to_date=$to_date;
		$this->page=$page;
		$this->title="我的预约";
		$this->display();
	}
	/*
	取消预约，即删除该时段的预约记录
	 */
	public function cancel_reserve()
	{
		if(!session('?valid_user'))
		{
			$this->redirect('Member/login_form');
		}
		$reserve_id=intval(I('get.reserve_id'));
		if(empty($reserve_id))
		{
			$this->error('参数错误!',U('Reserve/myReserve'));
		}
		$reservelog=M('reservelog');
		$result=$reservelog->where('id='.$reserve_id)->delete();
		if($result)
		{
			$this->redirect('Reserve/myReserve');
		}
		else
		{
			$this->error('删除失败，请稍后再试!<br/>'
				.'可能原因: 要删除的预约不存在!<br/>',U('Reserve/myReserve'));
		}
	}
	/*
	显示公告列表
	 */
	public function bulletin()
	{
		$where=array();
		$m=M('bulletin');
		$m->table('__BULLETIN__ bulletin')->join('LEFT JOIN __USER__ user ON user.username = bulletin.username')->field('bulletin.id as id , bulletin.username as username ,bulletin.content as content , bulletin.createtime as createtime , user.realname as realname');
		$p=getpage($m,$where);
		$page=$p->show();
		$nowPage=intval(I('get.p'));
		if($nowPage>intval($p->totalPages))
		{
			$this->redirect('Home/Reserve/bulletin',array('p'=>$totalPages));
		}
		$bulletin_list=$m->where($where)->order('createtime desc')->select();

		$this->bulletin_list=$bulletin_list;

		$this->page=$page;
		$this->title="公告板";
		$this->display();
	}
}
?>