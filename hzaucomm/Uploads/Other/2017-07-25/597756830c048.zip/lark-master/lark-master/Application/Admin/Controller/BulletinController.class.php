<?php
namespace Admin\Controller;
use Think\Controller;

class BulletinController extends Controller{
	/*
	显示公告管理列表
	 */
	public function bulletin_list()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}

		$where=array();
		$m=M('bulletin');
		$m->table('__BULLETIN__ bulletin')->join('LEFT JOIN __USER__ user ON user.username = bulletin.username')->field('bulletin.id as id , bulletin.username as username ,bulletin.content as content , bulletin.createtime as createtime , user.realname as realname');
		$p=getpage($m,$where);
		$page=$p->show();
		$nowPage=intval(I('get.p'));
		if($nowPage>intval($p->totalPages))
		{
			$this->redirect('Admin/Bulletin/bulletin_list',array('p'=>$totalPages));
		}
		$bulletin_list=$m->where($where)->order('createtime desc')->select();

		$this->bulletin_list=$bulletin_list;
		$this->title="公告管理";
		$this->page=$page;
		$this->display();
	}
	/*
	创建公告
	 */
	public function bulletin_add()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$content=I('post.content');
		if(empty($content))
		{
			alert('ERROR','公告内容不能为空!');
			exit;
		}
		$bulletin_table = M('bulletin');
		$data['username']=session('valid_user');
		$data['content']=$content;
		$result=$bulletin_table->add($data);
		if(!$result)
		{
			alert('ERROR','发布失败，请稍后再试!');
			exit;
		}
		$this->redirect('Admin/Bulletin/bulletin_list');
	}
	/**
	 * 删除公告记录
	 * @return [type] [description]
	 */
	public function bulletin_del()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$id=I('get.id');
		$bulletin_table=M('bulletin');
		$result=$bulletin_table->where('id='.$id)->delete();
		if($result)
		{
			redirect($_SERVER["HTTP_REFERER"]);
		}else
		{
			$this->error('删除失败,请稍后再试!',U('Permission/permission_list'));
		}
	}
}
?>