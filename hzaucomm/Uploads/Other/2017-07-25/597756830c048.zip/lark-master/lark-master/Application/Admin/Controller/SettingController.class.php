<?php
namespace Admin\Controller;
use Think\Controller;
class SettingController extends Controller{
	/*
	从config.php中读取配置
	 */
	public function setting_list()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$config = getConfig();
		$this->publish_day=$config['PUBLISH_DAY'];
		$this->publish_time=$config['PUBLISH_TIME'];
		$this->is_sunday_available=$config['IS_SUNDAY_AVAILABLE'];
		$this->hourlist=array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23);
		$this->title="设置";
		$this->display();
	}
	/*
	把用户设置更新到config.php
	 */
	public function updateSetting()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$publish_day=I('post.publish_day');
		$publish_time=I('post.publish_time');
		$is_sunday_available=I('post.is_sunday_available');
		if(!(update_config('PUBLISH_DAY',$publish_day) && 
			update_config('PUBLISH_TIME',$publish_time)&&
			update_config('IS_SUNDAY_AVAILABLE',$is_sunday_available)))
		{
			$this->error('修改失败，请稍后再试!',U('Setting/setting_list'));
		}
		if(clearCache())
			$this->success('修改成功！配置已经生效。',U('Setting/setting_list'));
		else
		{
			$this->error('自动清除缓存失败，请手动清除，清除前修改不生效.<br/>缓存目录：'.RUNTIME_PATH,U('Setting/setting_list'));
		}
	}
}