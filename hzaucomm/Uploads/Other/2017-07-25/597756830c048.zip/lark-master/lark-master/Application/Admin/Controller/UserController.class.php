<?php
namespace Admin\Controller;
use Think\Controller;
class UserController extends Controller{

	//显示会员列表
	public function user_list()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}

		$user_table=M('user');
		$where=array();
		$type=I('get.type');
		$wd=I('get.wd');
		if(!empty($type) && !empty($wd))
		{
			$where[$type]=array('like','%'.$wd.'%');
		}
		$p=getpage($user_table,$where);
		$page=$p->show();
		$nowPage=intval(I('get.p'));
		if($nowPage>intval($p->totalPages))
		{
			$this->redirect('User/user_list',array('p'=>$totalPages));
		}

		$user_list=$user_table->where($where)->order('createtime desc')->select();
		$this->user_list=$user_list;
		$this->page=$page;
		$this->wd=$wd;
		$this->type=$type;
		$this->title="用户管理";
		$this->display();
	}
	//删除会员
	public function user_delete()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$username=I('get.username');
		if(!$username) 
		{
			alert('ERROR','username参数错误!');
			exit;
		}
		$user_table=M('user');
		$condition['username']=$username;
		$result=$user_table->where($condition)->delete();
		if($result)
		{
			$this->redirect('User/user_list');
		}else
		{
			$this->error('用户删除失败,请稍后再试!');
		}
	}
	//修改会员信息
	public function user_modify()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$this->title="修改用户信息";
		$username=I('get.username');
		$user_table=M('user');
		$condition['username']=$username;
		$user=$user_table->where($condition)->find();
		$this->user=$user;
		$this->referer=$_SERVER['HTTP_REFERER'];
		$this->display();
	}
	//更新会员信息
	public function user_update()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$username=trim(I("post.username"));
		$passwd=trim(I("post.passwd"));
		$repasswd=trim(I("post.repasswd"));
		$realname=trim(I("post.realname"));
		$email=trim(I("post.email"));
		$phone=trim(I("post.phone"));
		$isadmin=trim(I("post.isadmin"));
		$referer=trim(I('post.referer'));

		if(empty($realname))
		{
			alert('ERROR','真实姓名不能为空!');
			exit;
		}
		if(!empty($passwd)&&!valid_passwd($passwd))
		{
			alert('ERROR','密码格式不合法，请重新输入!');
			exit;
		}
		if($passwd !== $repasswd)
		{
			alert('ERROR','两次密码不一致!');
			exit;
		}
		if(!empty($email) && !valid_email($email))
		{
			alert('ERROR','邮箱格式不正确，请重新输入!');
			exit;
		}
		if(!empty($phone) && !valid_phone($phone))
		{
			alert('ERROR','手机不合法，请重新输入!');
			exit;
		}
		$user_table=M('user');
		$condition['username']=$username;
		$data['realname']=$realname;
		if(!empty($passwd))$data['passwd']=sha1($passwd);
		$data['email']=$email;
		$data['phone']=$phone;
		if($username!='admin') $data['isadmin']=$isadmin;
		$result=$user_table->where($condition)->save($data);
		if($result||$result===0)
		{
			if(!empty($referer))
			{
				redirect($referer);
			}
			else
			{
				$this->redirect('User/user_list');
			}
		}else
		{
			$this->error('会员修改失败,请稍后再试!');
		}
	}
}
?>