<?php
/*
判断用户输入的时间段是否符合正则表达式
 */
function valid_rules($rules)
{
	return preg_match("/^((([01]\d)|(2[0-3])):[0-5]\d-(([01]\d)|(2[0-3])):[0-5]\d\s*,\s*)+$/", $rules.',');
}

?>