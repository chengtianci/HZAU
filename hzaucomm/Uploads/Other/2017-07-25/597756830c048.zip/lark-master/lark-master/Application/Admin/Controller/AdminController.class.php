<?php
namespace Admin\Controller;
use Think\Controller;
class AdminController extends Controller{
	public function index()
	{
		$this->redirect('Admin/Admin/login');
	}
	
	//管理员登陆认证
	public function login()
	{
		if (session('?valid_user')) {
			if(session('isadmin'))
			{
		      	$this->redirect('Admin/Admin/home');
			}
			else
			{
				$this->error('用户'.session('valid_user').'没有管理员权限!');
			}
		}
		else if(!IS_POST)
		{

			$this->redirect('Admin/Admin/login_form');
		}
		else
		{
			$username=trim(I('post.username'));
			$passwd=trim(I("post.passwd"));
			$user_table = M('user');
			$condition['username']=$username;
			$user=$user_table->where($condition)->find();
			if(!$user)
			{
				alert('ERROR','此管理员不存在!');
				exit;
			}
			else if(!$user['isadmin'])
			{
				alert('ERROR','此用户没有管理员权限!');
				exit;
			}
			else if($username===$user['username'] && sha1($passwd) === $user['passwd'])
			{
				session('valid_user',$username);
				session('isadmin',true);
			    $this->redirect('Admin/home');
			}else{
				alert('ERROR','用户名或密码不正确!');
				exit;
			}
		}
	}
	
	public function login_form()
	{
		if (session('?valid_user')) {
	      	$this->redirect('Admin/Admin/login');
		}else
		{
			$this->title="管理员登录";
			$this->display();
		}
	}
	//显示管理界面主页，如果没有登陆就重定向到login
	public function home()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}else
		{
			$this->redirect('Device/device_list');
		}
	}

	//退出登录
	public function logout()
	{
		if (session('?valid_user')) {
			$username=session('valid_user');
		    session(null);
			session('[destroy]');
			$this->success('用户'.$username.'退出成功',U('Home/Reserve/index'));
		}
		else{
			$this->error('你尚未登陆!',U('Home/Reserve/index'));
		}
	}
}
?>