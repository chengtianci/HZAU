<?php
namespace Home\Controller;
use Think\Controller;
class MemberController extends Controller{
	public function index()
	{
		$this->redirect('login');
	}
	public function login()
	{
		if (session('?valid_user')) {
	      $this->success('用户:'.session('valid_user').'已经登陆',U('Reserve/index'));
		}
		else if(!IS_POST)
		{
			$this->redirect('login_form');
		}
		else
		{
			$username=trim(I("post.username"));
			$passwd=trim(I("post.passwd"));
			
			$user_table = M('user');
			$condition['username']=$username;
			$user=$user_table->where($condition)->find();
			if(!$user)
			{
				$this->error('用户名不存在!');
			}
			else if($username===$user['username'] && sha1($passwd) === $user['passwd'])
			{
				session('valid_user',$username);
				if($user['isadmin'])
				{
					session('isadmin',1);
				}
			    $this->success('用户:'.session('valid_user').(session('?isadmin')?'(管理员)':'').'登陆成功',U('Home/Reserve/index'));
			}else{
				$this->error('用户名或密码不正确!');
			}
		}
	}
	//退出登录
	public function logout()
	{
		if (session('?valid_user')) {
			$username=session('valid_user');
		    session(null);
			session('[destroy]');
			$this->success('用户'.$username.'退出成功',U('Reserve/index'));
		}
		else{
			$this->error('你尚未登陆!',U('Reserve/index'));
		}
	}
	public function login_form()
	{
		if (session('?valid_user')) {
	      	$this->success('用户:'.session('valid_user').'已经登陆',U('Reserve/index'));
		}else
		{
			$this->title="用户登录";
			$this->display();
		}
	}
	/*
	注册
	 */
	public function register_form()
	{
		$this->title="新用户注册";
		$this->display();
	}
	//用户注册
	public function register()
	{
		if(!IS_POST)
		{
			$this->redirect('register_form');
		}
		$username=trim(I('post.username'));
		$passwd=trim(I('post.passwd'));
		$repasswd=trim(I('post.repasswd'));
		$realname=trim(I('post.realname'));
		$email=trim(I('post.email'));
		$phone=trim(I('post.phone'));

		if(!valid_username($username))
		{
			$this->error('用户名不能包含中文和特殊字符，且不少于三个字符!<br/>推荐使用真实姓名全拼，如张三: zhangsan');
		}
		if(!valid_realname($realname))
		{
			alert('ERROR','真实姓名不能为空，且只能包含中文!');
			exit;
		}
		if(!valid_email($email))
		{
			alert('ERROR','邮箱格式不正确，请重新输入!');
			exit;
		}
		if(!valid_phone($phone))
		{
			alert('ERROR','手机号码不合法，请重新输入!');
			exit;
		}
		if(!valid_passwd($passwd))
		{
			alert('ERROR','密码格式不合法，请重新输入!');
			exit;
		}
		if($passwd!==$repasswd)
		{
			alert('ERROR','两次密码不一致!');
			exit;
		}
		$user_table=M('user');
		$condition['username']=$username;
		$user= $user_table->where($condition)->find();
		if($user)
		{
			alert('ERROR','用户名已存在,请重新输入!');
			exit;
		}
		$data['username']=$username;
		$data['passwd']=sha1($passwd);
		$data['realname']=$realname;
		$data['email']=$email;
		$data['phone']=$phone;
		$result=$user_table->add($data);
		if(!$result)
		{
			alert('ERROR','注册失败，请稍后重试!');
			exit;
		}else
		{
			$this->success('注册成功!',U('Member/login'));
		}
	}
	/*
	显示预约人的联系方式，为了安全保证，需要登陆后才能显示
	 */
	public function contact()
	{
		if (!session('?valid_user')) {
			$this->redirect('Member/login_form');
		}

		$user_table=M('user');
		$where=array();
		$type=I('get.type');
		$wd=I('get.wd');
		if(!empty($type) && !empty($wd))
		{
			$where[$type]=array('like','%'.$wd.'%');
		}
		$p=getpage($user_table,$where);
		$page=$p->show();
		$nowPage=intval(I('get.p'));
		if($nowPage>intval($p->totalPages))
		{
			$this->redirect('Member/contact',array('p'=>$totalPages));
		}
		//按照中文拼音排序
		$user_list=$user_table->where($where)->order('convert( `realname`
USING gbk )')->select();
		$this->user_list=$user_list;
		$this->page=$page;
		$this->wd=$wd;
		$this->type=$type;
		$this->title="联系方式";
		$this->display();
	}
	/*
	修改个人信息
	 */
	public function editor()
	{
		if (!(session('?valid_user'))) {
		      $this->redirect('Member/login_form');
		}
		$this->title="修改个人信息";
		$username=session('valid_user');
		$user_table=M('user');
		$condition['username']=$username;
		$user=$user_table->where($condition)->find();
		$this->user=$user;
		$this->display();
	}
	/*
	更新个人信息
	 */
	public function update()
	{
		if (!(session('?valid_user'))) {
		      $this->redirect('Member/login_form');
		}
		$username=trim(I("post.username"));
		$passwd=trim(I("post.passwd"));
		$repasswd=trim(I("post.repasswd"));
		$realname=trim(I("post.realname"));
		$email=trim(I("post.email"));
		$phone=trim(I("post.phone"));
		
		if(!empty($passwd)&&!valid_passwd($passwd))
		{
			alert('ERROR','密码格式不合法，请重新输入!');
			exit;
		}
		if($passwd !== $repasswd)
		{
			alert('ERROR','两次密码不一致!');
			exit;
		}
		if(!valid_realname($realname))
		{
			alert('ERROR','真实姓名不能为空，且只能包含中文!');
			exit;
		}
		if(!empty($email) && !valid_email($email))
		{
			alert('ERROR','邮箱格式不正确，请重新输入!');
			exit;
		}
		if(!empty($phone) && !valid_phone($phone))
		{
			alert('ERROR','手机不合法，请重新输入!');
			exit;
		}
		$user_table=M('user');
		$condition['username']=$username;
		$data['realname']=$realname;
		if(!empty($passwd))$data['passwd']=sha1($passwd);
		$data['email']=$email;
		$data['phone']=$phone;
		$result=$user_table->where($condition)->save($data);
		if($result||$result===0)
		{
			$this->success('个人信息修改成功!',U('Reserve/index'));
		}else
		{
			$this->error('会员修改失败,请稍后再试!');
		}
	}
}
?>