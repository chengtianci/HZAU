<?php
return array(
	//'配置项'=>'配置值'
	'URL_PATHINFO_DEPR' => '/',
	// URL不区分大小写
	'URL_CASE_INSENSITIVE' => true,
	'DB_TYPE'=>'mysql',
	'DB_HOST'=>'127.0.0.1',
	'DB_NAME'=>'test',
	'DB_USER'=>'doubibobo',
	'DB_PWD'=>'12151618',
	'DB_PORT'=>3306,
	'DB_PREFIX'=>'reserve_',
	'DB_DEBUG' =>  false, // 数据库调试模式 开启后可以记录SQL日志
	'URL_HTML_SUFFIX'=>'',
	'URL_MODEL'=>1,
	'SHOW_PAGE_TRACE' => true,
	'PUBLISH_DAY' => 6 ,      //星期几开始下周的预约，取值范围[0-6]，代表周日-周六，周日是每周的第一天
	'PUBLISH_TIME' => 7 ,     //设置小时，只支持整点，取值范围[0-23]
	'IS_SUNDAY_AVAILABLE' => 0 ,    //周日是否接受预约，0表示不能预约，1表示可以预约
	'SESSION_EXPIRE'=>604800, //一星期秒数为 604800
	'SESSION_TYPE'=>'Db',
	'SESSION_TABLE'=>'think_session'
);