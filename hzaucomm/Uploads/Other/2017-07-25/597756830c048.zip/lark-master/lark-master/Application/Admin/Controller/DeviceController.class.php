<?php
namespace Admin\Controller;
use Think\Controller;
class DeviceController extends Controller{

	//显示添加设备表单
	public function device_list()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$device_table=M('device');
		$where=array();
		$type=I('get.type');
		$wd=I('get.wd');
		if(!empty($type) && !empty($wd))
		{
			$where[$type]=array('like','%'.$wd.'%');
		}
		$p=getpage($device_table,$where);
		$page=$p->show();
		$nowPage=intval(I('get.p'));
		if($nowPage>intval($p->totalPages))
		{
			$this->redirect('Device/device_list',array('p'=>$totalPages));
		}

		$device_list=$device_table->where($where)->order('id')->select();
		$this->page=$page;
		$this->wd=$wd;
		$this->type=$type;

		$this->title="设备管理";
		$this->device_list=$device_list;
		$this->display();

	}
	public function device_modify()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$this->title="修改设备信息";
		$id=I('get.id');
		$device_table=M('device');
		$condition['id']=$id;
		$device=$device_table->where($condition)->find();
		$this->device=$device;
		$this->display();
	}
	//更新设备信息
	public function device_update()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$id=trim(I("post.id"));
		$name=trim(I("post.name"));
		$rules=trim(I("post.rules"));
		$limit_count=trim(I("post.limit_count"));
		$description=trim(I("post.description"));
		
		if(empty($name))
		{
			alert('ERROR','设备名称不能为空!');
			exit;
		}
		if(!valid_rules($rules))
		{
			alert('ERROR','预约时间段不符合规则');
			exit;
		}
		if($limit_count==''||$limit_count<0)
		{
			$limit_count=-1;
		}
		$device_table=M('device');
		$condition['id']=$id;
		$data['name']=$name;
		$data['rules']=$rules;
		$data['limit_count']=$limit_count;
		$data['description']=$description;
		$result=$device_table->where($condition)->save($data);
		if($result||$result===0)
		{
			$this->success('设备修改成功!',U('Device/device_list'));
		}else
		{
			$this->error('设备修改失败,请稍后再试!');
		}
	}
	public function device_delete()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$id=I('get.id');
		if(!$id) 
		{
			alert('ERROR','设备id参数错误!');
			exit;
		}
		$device_table=M('device');
		$condition['id']=$id;
		$result=$device_table->where($condition)->delete();
		if($result)
		{
			$this->redirect('Device/device_list');
		}else if($result===0)
		{
			alert('WARN','设备不存在!');
		}
		else
		{
			$this->error('设备删除失败,请稍后再试!');
		}
	}
	//显示添加设备表单
	public function device_editor()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$this->title="添加设备";
		$this->display();

	}
	//添加设备
	public function add_device()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$name=trim(I('post.name'));
		$rules=trim(I('post.rules'));
		$limit_count=trim(I('post.limit_count'));
		$description=trim(I('post.description'));
		
		if($name=='')
		{
			$this->error('设备名称不能为空!');
		}
		if(!valid_rules($rules))
		{
			$this->error('预约时间段不符合规则!');
		}
		if($limit_count==''||$limit_count<0)
		{
			$limit_count=-1;
		}
		$device_table=M('device');
		$data['name']=$name;
		$data['rules']=$rules;
		$data['limit_count']=$limit_count;
		$data['description']=$description;
		$result=$device_table->add($data);
		if($result)
		{
			$this->success('设备添加成功!');
		}else
		{
			$this->error('设备添加失败,请稍后再试!');
		}
	}
}
?>