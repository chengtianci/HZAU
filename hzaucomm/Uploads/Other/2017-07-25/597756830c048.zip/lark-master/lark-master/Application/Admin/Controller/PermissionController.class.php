<?php
namespace Admin\Controller;
use Think\Controller;
class PermissionController extends Controller{
	/*
	打印权限列表
	 */
	public function permission_list()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$user_table=M('user');
		$device_table=M('device');
		$type=I('get.type');
		$wd=I('get.wd');
		$where=array();
		if(!empty($type) && !empty($wd))
		{
			$where[$type]=array('like','%'.$wd.'%');
		}
		$m=M('permission');
		$m->table('__PERMISSION__ permission')->join('LEFT JOIN __USER__ user ON user.username = permission.username')
		->join('LEFT JOIN __DEVICE__ device ON device.id = permission.device_id')
		->field('permission.id as id , permission.username as username ,permission.createtime as createtime , permission.device_id as device_id , permission.status as status , user.realname as realname , device.name as device_name');
		$p=getpage($m,$where);
		$page=$p->show();
		$nowPage=intval(I('get.p'));
		if($nowPage>intval($p->totalPages))
		{
			$this->redirect('Admin/Permission/permission_list',array('p'=>$totalPages));
		}

		$permission_list=$m->where($where)->order('createtime desc')->select();

		$user_list=$user_table->select();
		$device_list=$device_table->select();
		$this->user_list = $user_list;
		$this->device_list=$device_list;
		$this->permission_list=$permission_list;
		$this->wd=$wd;
		$this->type=$type;
		$this->page=$page;
		$this->title="权限管理";
		$this->display();
	}
	/**
	 * 添加权限记录到数据库
	 * @return [type] [description]
	 */
	public function permission_add()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$user_list=I('post.select_users');
		$device_list=I('post.select_device');
		$permission_table=M('permission');
		foreach ($user_list as $user) {
			foreach($device_list as $device)
			{
				$data['username']=$user;
				$data['device_id']=$device;
				$result=$permission_table->where($data)->find();
				if(!$result)
				{
					$permission_table->add($data);
				}
			}
		}
		$this->redirect('Admin/Permission/permission_list');
	}
	/**
	 * 删除权限记录，删除后可以预约
	 * @return [type] [description]
	 */
	public function permission_del()
	{
		if (!(session('?valid_user')&&session('isadmin'))) {
		      $this->redirect('Admin/login');
		}
		$id=I('get.id');
		$permission_table=M('permission');
		$result=$permission_table->where('id='.$id)->delete();
		if($result)
		{
			redirect($_SERVER["HTTP_REFERER"]);
		}else
		{
			$this->error('删除失败,请稍后再试!',U('Permission/permission_list'));
		}
	}
}
?>