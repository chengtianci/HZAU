use test;

/*
用数据库保存session
 */
create table think_session (
    session_id varchar(255) NOT NULL,
    session_expire int(11) NOT NULL,
    session_data blob,
    UNIQUE KEY `session_id` (`session_id`)
  )engine=innodb DEFAULT charset=utf8;
/*
 创建用户表
*/
create table reserve_user
(   username varchar(50) not null primary key,
  	passwd char(40) not null,
    email varchar(100) not null,
  	phone varchar(20) not null,
  	realname varchar(100) not null,
  	isadmin boolean default false,
  	createtime timestamp not null DEFAULT CURRENT_TIMESTAMP
)engine=innodb default charset=utf8;
/*
 创建设备表
*/
create table reserve_device
( id int not null primary key auto_increment,
  name varchar(255) not null unique,
  rules varchar(1024),
  limit_count int default -1,
  description text,
  createtime timestamp not null DEFAULT CURRENT_TIMESTAMP
)engine=innodb default charset=utf8;

/*
创建预约记录表
 */
create table reserve_reservelog
(
  id int not null primary key  auto_increment,
  username char(40) not null,
  device_id int not null, 
  `date` date not null,
  period varchar(50) not null,
  createtime timestamp not null DEFAULT CURRENT_TIMESTAMP,
  status int not null default 0,
  foreign key(username) references reserve_user(username) ON UPDATE CASCADE ON DELETE CASCADE,
  foreign key(device_id) references reserve_device(id) ON UPDATE CASCADE ON DELETE CASCADE
)engine=innodb default charset=utf8;
/*
预约权限设置,新用户没有预约权限,表中的选项代表着用户可以预约相应设备,status字段暂时没有什么用处，程序中认为status=1时拥有预约权限
 */
create table reserve_permission
(
  id int not null primary key  auto_increment,
  username char(40) not null,
  device_id int not null,
  status int not null default 1,
  createtime timestamp not null DEFAULT CURRENT_TIMESTAMP,
  foreign key(username) references reserve_user(username) ON UPDATE CASCADE ON DELETE CASCADE,
  foreign key(device_id) references reserve_device(id) ON UPDATE CASCADE ON DELETE CASCADE
)engine=innodb default charset=utf8;
/*
公告表
 */
create table reserve_bulletin
(
  id int not null primary key  auto_increment,
  username char(40) not null,
  content text not null,
  createtime timestamp not null DEFAULT CURRENT_TIMESTAMP,
  foreign key(username) references reserve_user(username) ON UPDATE CASCADE ON DELETE CASCADE
)engine=innodb default charset=utf8;


insert into reserve_user(`username`,`passwd`,`email`,`realname`,`isadmin`) values ('admin', sha1('admin'),'','管理员', true);

insert into reserve_device(name,rules,limit_count) values('半导体分析仪B1500A','08:30-10:30, 10:30-13:30, 13:30-15:30, 15:30-18:00, 18:00-20:00',2);
insert into reserve_device(name,rules,limit_count) values('半导体分析仪4200(测试间)','08:00-12:30, 12:30-16:30, 16:30-20:30',2);
insert into reserve_device(name,rules) values('旧溅射台','08:30-10:30, 10:30-13:30, 13:30-15:30, 15:30-18:00, 18:00-20:00');
insert into reserve_device(name,rules) values('紫外光刻机','08:30-10:30, 10:30-13:30, 13:30-15:30, 15:30-18:00, 18:00-20:00');
insert into reserve_device(name,rules) values('腐蚀清洗机','08:30-10:30, 10:30-13:30, 13:30-15:30, 15:30-18:00, 18:00-20:00');
insert into reserve_device(name,rules) values('旋转冲洗甩干机','08:30-10:30, 10:30-13:30, 13:30-15:30, 15:30-18:00, 18:00-20:00');
insert into reserve_device(name,rules) values('溅射台MSP','08:30-10:30, 10:30-13:30, 13:30-15:30, 15:30-18:00, 18:00-20:00');
insert into reserve_device(name,rules) values('溅射台syskey','08:30-10:30, 10:30-13:30, 13:30-15:30, 15:30-18:00, 18:00-20:00');
insert into reserve_device(name,rules) values('旧台阶仪','08:30-10:30, 10:30-13:30, 13:30-15:30, 15:30-18:00, 18:00-20:00');
insert into reserve_device(name,rules) values('新台阶仪(测试间)','08:30-10:30, 10:30-13:30, 13:30-15:30, 15:30-18:00, 18:00-20:00');
insert into reserve_device(name,rules) values('PECVD-400','08:30-10:30, 10:30-13:30, 13:30-15:30, 15:30-18:00, 18:00-20:00');
insert into reserve_device(name,rules) values('RIE','08:30-10:30, 10:30-13:30, 13:30-15:30, 15:30-18:00, 18:00-20:00');
insert into reserve_device(name,rules) values('PECVD & RIE','08:30-10:30, 10:30-13:30, 13:30-15:30, 15:30-18:00, 18:00-20:00');
insert into reserve_device(name,rules) values('退火炉','08:30-10:30, 10:30-13:30, 13:30-15:30, 15:30-18:00, 18:00-20:00');
insert into reserve_device(name,rules) values('200V阳极氧化系统','08:30-10:30, 10:30-13:30, 13:30-15:30, 15:30-18:00, 18:00-20:00');
