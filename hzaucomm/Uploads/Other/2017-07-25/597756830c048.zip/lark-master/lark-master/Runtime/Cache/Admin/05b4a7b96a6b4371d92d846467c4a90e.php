<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-theme.min.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap.min.css">
		<!--[if lt IE 9]>
	      <script src="/lark-master/lark-master/Public/Common/js/html5shiv.min.js"></script>
	      <script src="/lark-master/lark-master/Public/Common/js/respond.min.js"></script>
	    <![endif]-->
		<script src="/lark-master/lark-master/Public/Common/js/jquery.min.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/bootstrap.min.js"></script>
		<!-- <script src="/lark-master/lark-master/Public/Common/js/bootstrap-wysiwyg.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/jquery.hotkeys.js" type="text/javascript"></script> -->
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Admin/css/style.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/multiple-select.css" />
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/style.css">
		<!-- <link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-combined.no-icons.min.css">
	    <link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-responsive.min.css">
	    <link href="http://netdna.bootstrapcdn.com/font-awesome/3.0.2/css/font-awesome.css" rel="stylesheet"> -->
		<title><?php echo ($title); ?></title>
	</head>
	<body>
<div class="container">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<a href="/lark-master/lark-master"><img src="/lark-master/lark-master/Public/Home/img/logo.png" style="width:200px"></a>
			</div>
			
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
					<li <?php if(($title) == "设备管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Device/device_list');?>">设备管理</a></li>
					<li <?php if(($title) == "添加设备"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Device/device_editor');?>">添加设备</a></li>
					<li <?php if(($title) == "用户管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('User/user_list');?>">用户管理</a></li>
					<li <?php if(($title) == "权限管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Permission/permission_list');?>">权限管理</a></li>
					<li <?php if(($title) == "公告管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Bulletin/bulletin_list');?>">公告管理</a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li <?php if(($title) == "设置"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Setting/setting_list');?>">设置</a></li>
					<li><a><?php echo session('valid_user');?></a></li>
					<li><a href="<?php echo U('Admin/logout');?>">退出</a></li>
				</ul>
			</div>
		</div>
	</nav>
</div>
<br/>
<br/>
<!--显示修改设备的表单-->
<div class="container">
	<div class="device_modify">
		<div class="col-md-9 heading col-md-offset-2">
			修改设备信息
		</div>
		<br/>
		<br/>
		<form class="form-horizontal" role="form" method="post" action="<?php echo U('Device/device_update');?>" onkeydown="if(event.keyCode==13){return false;}">
			<div class="form-group">
				<label for="id" class="col-md-2 control-label">设&nbsp;备&nbsp;ID</label>
				<div class="col-md-9">
					<input type="text" class="form-control" id="id" name="id" placeholder="如非必要请勿修改" readonly="readonly" value="<?php echo ($device['id']); ?>">
				</div>
			</div>
			<div class="form-group">
				<label for="name" class="col-md-2 control-label">设备名称</label>
				<div class="col-md-9">
					<input type="text" class="form-control" id="name" name="name" placeholder="设备名称 (不能为空)" value="<?php echo ($device['name']); ?>">
				</div>
			</div>
			<div class="form-group">
				<label for="rules" class="col-md-2 control-label">时&nbsp;间&nbsp;段</label>
				<div class="col-md-9">
					<input type="text" class="form-control" id="rules" name="rules" placeholder="预约时间段 (不能为空)" value="<?php echo ($device['rules']); ?>">
				</div>
			</div>
			<div class="form-group">
				<label for="limit_count" class="col-md-2 control-label">次数&nbsp;/&nbsp;周</label>
				<div class="col-md-9">
					<input type="text" class="form-control" id="limit_count" name="limit_count" placeholder="-1或留空表示不限次数, 0表示禁止预约" value="<?php echo ($device['limit_count']); ?>">
				</div>
			</div>
			<div class="form-group">
				<label for="description" class="col-md-2 control-label">备&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;注</label>
				<div class="col-md-9">
					<input type="text" class="form-control" id="description" name="description" placeholder="备注 (可以为空)" value="<?php echo ($device['description']); ?>">
				</div>
			</div>
			<br/>
			<div class="form-group">
				<div class="col-md-offset-2 col-md-10">
					<button class="btn btn-primary btn-md col-md-5" name="modify" onclick="javascript:history.back()">取消</button>
					<span class="col-md-1"></span>
					<button type="submit" class="btn btn-success btn-md col-md-5" name="modify">确认修改</button>
				</div>
			</div>
		</form>
	</div>
</div>

<!--页脚-->
		<!--页脚-->
	<div class="container">
		<div id="footer">
		    <p title="世博">©2015 <a href="mailto:taoshibopku@126.com">Administrator</a></p>
		</div>
	</div>
</body>
</html>