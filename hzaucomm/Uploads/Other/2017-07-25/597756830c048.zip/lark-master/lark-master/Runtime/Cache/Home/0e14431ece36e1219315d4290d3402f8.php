<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-theme.min.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap.min.css">
		<!--[if lt IE 9]>
	      <script src="/lark-master/lark-master/Public/Common/js/html5shiv.min.js"></script>
	      <script src="/lark-master/lark-master/Public/Common/js/respond.min.js"></script>
	    <![endif]-->
		<script src="/lark-master/lark-master/Public/Common/js/jquery.min.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/bootstrap.min.js"></script>
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Home/css/style.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/style.css">
		<link rel="stylesheet" type="text/css" href="/lark-master/lark-master/Public/Home/js/tcal.css" />
		<script type="text/javascript" src="/lark-master/lark-master/Public/Home/js/tcal.js"></script> 
		<title><?php echo ($title); ?></title>
	</head>
	<body>
<div class="container-fluid">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<a href="/lark-master/lark-master"><img src="/lark-master/lark-master/Public/Home/img/logo.png" style="width:200px"></a>
			</div>
			
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
					<li <?php if(($title) == "首页"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/home');?>">首页</a></li>
					<li <?php if(($title) == "预约设备"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/reserve');?>">预约设备</a></li>
					<li <?php if(($title) == "我的预约"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/myReserve');?>">我的预约</a></li>
					<li <?php if(($title) == "联系方式"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Member/contact');?>">联系方式</a></li>
					<li <?php if(($title) == "公告板"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/bulletin');?>">公告板</a></li>
					<li><a href="<?php echo U('Admin/Admin/login');?>">后台管理</a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<?php
 if(!session('valid_user')) { ?>
					<li <?php if(($title) == "新用户注册"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Member/register');?>">注册</a></li>
					<li><a href="<?php echo U('Member/login');?>">登陆</a></li>
					<?php
 }else { ?>
					<li title="个人信息"><a href="<?php echo U('Member/editor');?>"><?php echo session('valid_user');?></a></li>
					<li><a href="<?php echo U('Member/logout');?>">退出</a></li>
					<?php
 } ?>
				</ul>
			</div>
		</div>
	</nav>
</div>
<div class="container-fluid">
	<div class="today_date">
		今天: 
		<?php
 $date=date('Y-m-d'); echo $date.' '.getWeek($date); ?>
	</div>
</div>

<!--显示member 联系方式-->
<div class="container">
	
	<div class="bulletin_list">
		<div class="col-sm-12 heading">公告板</div>
		<br/>
		<table class="table table-bordered">
			<colgroup>
				<col width="10%">
				<col width="">
				<col width="20%">
			</colgroup>
			<thead class="table-head">
				<tr>
					<td>发布人</td>
					<td>公告内容</td>
					<td>发布时间</td>
				</tr>
			</thead>
			<tbody>
				<?php if(is_array($bulletin_list)): $i = 0; $__LIST__ = $bulletin_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><tr <?php if(($mod) == "1"): ?>class="odd"<?php endif; ?>>
					<td title="<?php echo ($item["username"]); ?>"><?php echo ($item["realname"]); ?></td>
					<td><?php echo ($item["content"]); ?></td>
					<td><?php echo ($item["createtime"]); ?></td>
				</tr><?php endforeach; endif; else: echo "" ;endif; ?>
			</tbody>
		</table>
	</div>
</div>

<div class="container">
	<div class="pagesplit" style="colspan:3 bgcolor:#FFF">
		<?php echo ($page); ?>
	</div>
</div>
		<!--页脚-->
	<div class="container">
		<div id="footer">
		    <p title="世博">©2015 <a href="mailto:taoshibopku@126.com">Administrator</a></p>
		</div>
	</div>
</body>
</html>