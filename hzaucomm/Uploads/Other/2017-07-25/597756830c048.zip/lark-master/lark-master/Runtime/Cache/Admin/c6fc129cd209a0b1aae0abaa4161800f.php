<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-theme.min.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap.min.css">
		<!--[if lt IE 9]>
	      <script src="/lark-master/lark-master/Public/Common/js/html5shiv.min.js"></script>
	      <script src="/lark-master/lark-master/Public/Common/js/respond.min.js"></script>
	    <![endif]-->
		<script src="/lark-master/lark-master/Public/Common/js/jquery.min.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/bootstrap.min.js"></script>
		<!-- <script src="/lark-master/lark-master/Public/Common/js/bootstrap-wysiwyg.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/jquery.hotkeys.js" type="text/javascript"></script> -->
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Admin/css/style.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/multiple-select.css" />
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/style.css">
		<!-- <link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-combined.no-icons.min.css">
	    <link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-responsive.min.css">
	    <link href="http://netdna.bootstrapcdn.com/font-awesome/3.0.2/css/font-awesome.css" rel="stylesheet"> -->
		<title><?php echo ($title); ?></title>
	</head>
	<body>
<div class="container">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<a href="/lark-master/lark-master"><img src="/lark-master/lark-master/Public/Home/img/logo.png" style="width:200px"></a>
			</div>
			
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
					<li <?php if(($title) == "设备管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Device/device_list');?>">设备管理</a></li>
					<li <?php if(($title) == "添加设备"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Device/device_editor');?>">添加设备</a></li>
					<li <?php if(($title) == "用户管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('User/user_list');?>">用户管理</a></li>
					<li <?php if(($title) == "权限管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Permission/permission_list');?>">权限管理</a></li>
					<li <?php if(($title) == "公告管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Bulletin/bulletin_list');?>">公告管理</a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li <?php if(($title) == "设置"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Setting/setting_list');?>">设置</a></li>
					<li><a><?php echo session('valid_user');?></a></li>
					<li><a href="<?php echo U('Admin/logout');?>">退出</a></li>
				</ul>
			</div>
		</div>
	</nav>
</div>
<br/>
<div class="container">
	<div id="signupbox" style="margin-top:50px" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
		<div class="panel panel-info">
			<div class="panel-heading">
				<div class="panel-title" style="text-align:center">预约设置</div>
			</div>
			<div class="panel-body" >
				<form id="setting_form" class="form-horizontal" role="form" action="<?php echo U('Setting/updateSetting');?>" method="POST">
					<div class="form-group">
						<label for="publish_day" class="col-md-3 control-label">星&nbsp;&nbsp;&nbsp;期</label>
						<div class="col-md-3">
							<select class="selectpicker form-control" name="publish_day">
								<option value="1" <?php if(($publish_day) == "1"): ?>selected<?php endif; ?>>一</option>
								<option value="2" <?php if(($publish_day) == "2"): ?>selected<?php endif; ?>>二</option>
								<option value="3" <?php if(($publish_day) == "3"): ?>selected<?php endif; ?>>三</option>
								<option value="4" <?php if(($publish_day) == "4"): ?>selected<?php endif; ?>>四</option>
								<option value="5" <?php if(($publish_day) == "5"): ?>selected<?php endif; ?>>五</option>
								<option value="6" <?php if(($publish_day) == "6"): ?>selected<?php endif; ?>>六</option>
								<option value="0" <?php if(($publish_day) == "0"): ?>selected<?php endif; ?>>日</option>
							</select>
						</div>
						<div class="note">
							从周几开始下周的预约
						</div>
					</div>
					<div class="form-group">
						<label for="publish_time" class="col-md-3 control-label">小&nbsp;&nbsp;&nbsp;时</label>
						<div class="col-md-3">
							<select class="selectpicker form-control" name="publish_time">
								<?php if(is_array($hourlist)): $i = 0; $__LIST__ = $hourlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><option value="<?php echo ($item); ?>" <?php if(($item) == $publish_time): ?>selected<?php endif; ?>><?php echo ($item); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
							</select>
						</div>
						<div class="note">
							从几点开始下周的预约
						</div>
					</div>
					<div class="form-group">
						<label for="is_sunday_available" class="col-md-3 control-label">周&nbsp;&nbsp;&nbsp;日</label>
						<div class="col-md-3">
							<select class="selectpicker form-control" name="is_sunday_available">
								<option value="1" <?php if(($is_sunday_available) == "1"): ?>selected<?php endif; ?>>是</option>
								<option value="0" <?php if(($is_sunday_available) == "0"): ?>selected<?php endif; ?>>否</option>
							</select>
						</div>
						<div class="note">
							周日是否可以预约
						</div>
					</div>
					
					<div class="form-group">
						<div class="col-md-offset-2 col-md-10">
							<button class="btn btn-primary btn-md col-md-3" name="modify" onclick="javascript:history.back()">取消</button>
							<span class="col-md-1"></span>
							<button type="submit" class="btn btn-success btn-md col-md-3" name="modify">确认</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
		<!--页脚-->
	<div class="container">
		<div id="footer">
		    <p title="世博">©2015 <a href="mailto:taoshibopku@126.com">Administrator</a></p>
		</div>
	</div>
</body>
</html>