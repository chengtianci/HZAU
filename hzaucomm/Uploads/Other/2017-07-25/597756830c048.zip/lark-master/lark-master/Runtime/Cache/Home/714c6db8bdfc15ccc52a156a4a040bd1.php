<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-theme.min.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap.min.css">
		<!--[if lt IE 9]>
	      <script src="/lark-master/lark-master/Public/Common/js/html5shiv.min.js"></script>
	      <script src="/lark-master/lark-master/Public/Common/js/respond.min.js"></script>
	    <![endif]-->
		<script src="/lark-master/lark-master/Public/Common/js/jquery.min.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/bootstrap.min.js"></script>
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Home/css/style.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/style.css">
		<link rel="stylesheet" type="text/css" href="/lark-master/lark-master/Public/Home/js/tcal.css" />
		<script type="text/javascript" src="/lark-master/lark-master/Public/Home/js/tcal.js"></script> 
		<title><?php echo ($title); ?></title>
	</head>
	<body>
<div class="container-fluid">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<a href="/lark-master/lark-master"><img src="/lark-master/lark-master/Public/Home/img/logo.png" style="width:200px"></a>
			</div>
			
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
					<li <?php if(($title) == "首页"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/home');?>">首页</a></li>
					<li <?php if(($title) == "预约设备"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/reserve');?>">预约设备</a></li>
					<li <?php if(($title) == "我的预约"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/myReserve');?>">我的预约</a></li>
					<li <?php if(($title) == "联系方式"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Member/contact');?>">联系方式</a></li>
					<li <?php if(($title) == "公告板"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/bulletin');?>">公告板</a></li>
					<li><a href="<?php echo U('Admin/Admin/login');?>">后台管理</a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<?php
 if(!session('valid_user')) { ?>
					<li <?php if(($title) == "新用户注册"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Member/register');?>">注册</a></li>
					<li><a href="<?php echo U('Member/login');?>">登陆</a></li>
					<?php
 }else { ?>
					<li title="个人信息"><a href="<?php echo U('Member/editor');?>"><?php echo session('valid_user');?></a></li>
					<li><a href="<?php echo U('Member/logout');?>">退出</a></li>
					<?php
 } ?>
				</ul>
			</div>
		</div>
	</nav>
</div>
<div class="container-fluid">
	<div class="today_date">
		今天: 
		<?php
 $date=date('Y-m-d'); echo $date.' '.getWeek($date); ?>
	</div>
</div>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-10">
			<form action="<?php echo U('Home/Reserve/home');?>" method="get">
				选择日期:
				<input type="text" name="date" class="tcal" value="<?php echo ($show_date); ?>" />&nbsp;&nbsp;
				<button type="submit" class="btn btn-primary btn-sm ">查询</button>
			</form>
			<table class="table table-bordered table-hover">
				<caption><?php echo ($show_date); ?> 预定情况，红色表示已经被预约的时间段</caption>
				<colgroup>
				<col width="20%">
				</colgroup>
				<tbody>
					<?php
 $i=0; foreach($device_list as $key=>$value) { ?>
					<tr class="<?php echo $i%2==0?'even':'odd';?>">
						<th scope="row"><?php echo $value['name'];?></th>
						<?php
 $rules=preg_split('/,\s*/',$value['rules']); $users=preg_split('/,\s*/',$value['reserveby']); for($k=0;$k<count($rules);$k++) { ?>
						<td title="<?php echo $users[$k]=='0'?'':$users[$k]; ?>" class="<?php echo $users[$k]=='0'?'available':'unavailable';?>">
							<?php echo $rules[$k]; ?>
							<span class="stu_name"> <?php echo '&nbsp;&nbsp;'.($users[$k]=='0'?'':$users[$k]).'&nbsp;'; ?></span>
						</td>
						<?php
 } ?>
					</tr>
					<?php
 $i++; } ?>
				</tbody>
			</table>
		</div>
		<!--/span-->
		<div class="col-md-2">
			<div class="sidebar-nav-fixed">
					<ul class="nav bulletin">
						<li class="bulletin-title">公告板<span class="more"><a href="/lark-master/lark-master/index.php/Home/Reserve/bulletin">更多</a></span></li>
						<li class="divider"></li>
						<?php if(is_array($bulletin_list)): $i = 0; $__LIST__ = $bulletin_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><li class="divider"></li>
							<li>发&nbsp;&nbsp;布&nbsp;&nbsp;者:<span class="bulletin_publisher"><?php echo ($item["realname"]); ?></span></li>
							<li>发布日期:<span class="bulletin_time"><?php $strs=preg_split('/\s+/', $item['createtime']); if(count($strs)>0) echo $strs[0]; ?></span></li>
							<li>内&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;容:<span class="bulletin_content"><?php echo ($item["content"]); ?></span></li><?php endforeach; endif; else: echo "" ;endif; ?>
					</ul>
			</div>
			<!--/sidebar-nav-fixed -->
		</div>
	</div>
</div>
		<!--页脚-->
	<div class="container">
		<div id="footer">
		    <p title="世博">©2015 <a href="mailto:taoshibopku@126.com">Administrator</a></p>
		</div>
	</div>
</body>
</html>