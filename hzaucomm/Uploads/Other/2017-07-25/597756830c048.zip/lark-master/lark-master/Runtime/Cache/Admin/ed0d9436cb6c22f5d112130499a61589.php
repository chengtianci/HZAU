<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-theme.min.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap.min.css">
		<!--[if lt IE 9]>
	      <script src="/lark-master/lark-master/Public/Common/js/html5shiv.min.js"></script>
	      <script src="/lark-master/lark-master/Public/Common/js/respond.min.js"></script>
	    <![endif]-->
		<script src="/lark-master/lark-master/Public/Common/js/jquery.min.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/bootstrap.min.js"></script>
		<!-- <script src="/lark-master/lark-master/Public/Common/js/bootstrap-wysiwyg.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/jquery.hotkeys.js" type="text/javascript"></script> -->
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Admin/css/style.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/multiple-select.css" />
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/style.css">
		<!-- <link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-combined.no-icons.min.css">
	    <link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-responsive.min.css">
	    <link href="http://netdna.bootstrapcdn.com/font-awesome/3.0.2/css/font-awesome.css" rel="stylesheet"> -->
		<title><?php echo ($title); ?></title>
	</head>
	<body>
<div class="container">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<a href="/lark-master/lark-master"><img src="/lark-master/lark-master/Public/Home/img/logo.png" style="width:200px"></a>
			</div>
			
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
					<li <?php if(($title) == "设备管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Device/device_list');?>">设备管理</a></li>
					<li <?php if(($title) == "添加设备"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Device/device_editor');?>">添加设备</a></li>
					<li <?php if(($title) == "用户管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('User/user_list');?>">用户管理</a></li>
					<li <?php if(($title) == "权限管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Permission/permission_list');?>">权限管理</a></li>
					<li <?php if(($title) == "公告管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Bulletin/bulletin_list');?>">公告管理</a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li <?php if(($title) == "设置"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Setting/setting_list');?>">设置</a></li>
					<li><a><?php echo session('valid_user');?></a></li>
					<li><a href="<?php echo U('Admin/logout');?>">退出</a></li>
				</ul>
			</div>
		</div>
	</nav>
</div>
<!--显示折叠按钮 -->
<div class="container">
	<div class="col-md-offset-11">
		<a href="#">
			<img src="/lark-master/lark-master/Public/Admin/imgs/add.png" style="cursor:hand;" alt="添加权限" title="添加权限" onclick="javascript:displayForm()">
		</a>
	</div>
</div>
<!--设置权限-->
<div class="container" id="permission_add_form" style="display:none;">
	
	<form class="form-horizontal" name="permission_form" action="<?php echo U('Permission/permission_add');?>" method="POST">
		<div class="form-group">
			<div class="col-md-6">
				<label for="select_users">选择用户<span class="note">(多选)</span></label>
				<select id="ms1" multiple="multiple" name="select_users[]">
					<?php if(is_array($user_list)): $i = 0; $__LIST__ = $user_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><option value="<?php echo ($item["username"]); ?>"><?php echo ($item["realname"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
				</select>
			</div>
			
			<div class="col-md-6">
				<label for="select_device">选择设备<span class="note">(多选)</span></label>
				<select id="ms2" multiple="multiple" name="select_device[]" style="height: 200px">
					<?php if(is_array($device_list)): $i = 0; $__LIST__ = $device_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><option value="<?php echo ($item["id"]); ?>"><?php echo ($item["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
				</select>
			</div>
		</div>
		<div class="form-group">
			<br/>
			<div class="col-md-12">
				<button type="submit" class="btn btn-success btn-md btn-block" name="add_user">确认授权</button>
			</div>
		</div>
	</form>
</div>
<script src="/lark-master/lark-master/Public/Common/js/jquery.multiple.select.js"></script>
<script>
var flag=true;
function displayForm()
{
var div=document.getElementById("permission_add_form");
if(flag)
div.style.display="block";
else
div.style.display="none";
flag=!flag;
}
$(function() {
$('#ms1').change(function() {
console.log($(this).val());
}).multipleSelect({
width: '100%'
});
});
$(function() {
$('#ms2').change(function() {
console.log($(this).val());
}).multipleSelect({
width: '100%'
});
});
</script>
<br/>
<!--显示权限设置列表-->
<div class="container">
	<div class="col-md-8">
		<form action="<?php echo U('Admin/Permission/permission_list');?>" method="get" class="form-horizontal">
			<div class="form-group">
				<div class="col-sm-2">
					<select class="selectpicker form-control" name="type">
						<option value="realname" <?php if(($type) == "realname"): ?>selected<?php endif; ?>>姓名</option>
						<option value="device.name" <?php if(($type) == "device.name"): ?>selected<?php endif; ?>>设备名</option>
					</select>
				</div>
				<div class="col-sm-3">
					<input type="text" name="wd" class="form-control" value="<?php echo ($wd); ?>">
				</div>
				<div class="col-sm-1">
					<button type="submit" class="btn btn-primary btn-sm ">查询</button>
				</div>
			</div>
		</form>
	</div>
	<br/>
	<br/>
	<div class="permission_list">
		<div class="col-sm-12 heading">权限管理(<em>已授权列表</em>)</div>
		<br/>
		<table class="table table-bordered">
			<thead class="table-head">
				<tr>
					<td>姓名</td>
					<td>设备</td>
					<td>状态</td>
					<td>授权时间</td>
					<td>取消授权</td>
				</tr>
			</thead>
			<tbody>
				<?php if(is_array($permission_list)): $i = 0; $__LIST__ = $permission_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><tr <?php if(($mod) == "1"): ?>class="odd"<?php endif; ?>>
					<td title="<?php echo ($item["username"]); ?>"><?php echo ($item["realname"]); ?></td>
					<td><?php echo ($item["device_name"]); ?></td>
					<td><?php if(($item["status"]) == "0"): ?>禁止预约<?php else: ?>允许预约<?php endif; ?></td>
					<td><?php echo ($item["createtime"]); ?></td>
					<td>
						<a href="/lark-master/lark-master/index.php/Admin/Permission/permission_del/id/<?php echo ($item["id"]); ?>">
							<img src="/lark-master/lark-master/Public/Admin/imgs/delete.png" width="20px" height="20px" alt="取消授权">
						</a>
					</td>
				</tr><?php endforeach; endif; else: echo "" ;endif; ?>
			</tbody>
		</table>
	</div>
</div>
<div class="container">
	<div class="pagesplit" style="colspan:3 bgcolor:#FFF">
		<?php echo ($page); ?>
	</div>
</div>
		<!--页脚-->
	<div class="container">
		<div id="footer">
		    <p title="世博">©2015 <a href="mailto:taoshibopku@126.com">Administrator</a></p>
		</div>
	</div>
</body>
</html>