<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-theme.min.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap.min.css">
		<!--[if lt IE 9]>
	      <script src="/lark-master/lark-master/Public/Common/js/html5shiv.min.js"></script>
	      <script src="/lark-master/lark-master/Public/Common/js/respond.min.js"></script>
	    <![endif]-->
		<script src="/lark-master/lark-master/Public/Common/js/jquery.min.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/bootstrap.min.js"></script>
		<!-- <script src="/lark-master/lark-master/Public/Common/js/bootstrap-wysiwyg.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/jquery.hotkeys.js" type="text/javascript"></script> -->
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Admin/css/style.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/multiple-select.css" />
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/style.css">
		<!-- <link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-combined.no-icons.min.css">
	    <link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-responsive.min.css">
	    <link href="http://netdna.bootstrapcdn.com/font-awesome/3.0.2/css/font-awesome.css" rel="stylesheet"> -->
		<title><?php echo ($title); ?></title>
	</head>
	<body>
<div class="container">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<a href="/lark-master/lark-master"><img src="/lark-master/lark-master/Public/Home/img/logo.png" style="width:200px"></a>
			</div>
			
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
					<li <?php if(($title) == "设备管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Device/device_list');?>">设备管理</a></li>
					<li <?php if(($title) == "添加设备"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Device/device_editor');?>">添加设备</a></li>
					<li <?php if(($title) == "用户管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('User/user_list');?>">用户管理</a></li>
					<li <?php if(($title) == "权限管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Permission/permission_list');?>">权限管理</a></li>
					<li <?php if(($title) == "公告管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Bulletin/bulletin_list');?>">公告管理</a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li <?php if(($title) == "设置"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Setting/setting_list');?>">设置</a></li>
					<li><a><?php echo session('valid_user');?></a></li>
					<li><a href="<?php echo U('Admin/logout');?>">退出</a></li>
				</ul>
			</div>
		</div>
	</nav>
</div>
<br/>
<!--显示设备列表-->
<div class="container">
	<div class="col-md-8">
		<form action="<?php echo U('Admin/Device/device_list');?>" method="get" class="form-horizontal">
			<div class="form-group">
				<div class="col-sm-3">
					<select class="selectpicker form-control" name="type">
						<option value="name" <?php if(($type) == "name"): ?>selected<?php endif; ?>>设备名称</option>
					</select>
				</div>
				<div class="col-sm-3">
					<input type="text" name="wd" class="form-control" value="<?php echo ($wd); ?>">
				</div>
				<div class="col-sm-1">
					<button type="submit" class="btn btn-primary btn-sm ">查询</button>
				</div>
			</div>
		</form>
	</div>
	<br/>
	<br/>

	<div class="device_list">
		<div class="col-sm-12 heading"><?php echo ($title); ?></div>
		<br/>
		<table class="table table-bordered" id="news_table">
			<colgroup>
			<col width="5%">
			</colgroup>
			<thead class="table-head">
				<tr>
					<td>编号</td>
					<td>设备名称</td>
					<td>预约时间段</td>
					<td>预约次数/周</td>
					<td>描述</td>
					<td>修改</td>
					<td>删除</td>
				</tr>
			</thead>
			<tbody>
				<?php if(is_array($device_list)): $i = 0; $__LIST__ = $device_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><tr <?php if(($mod) == "1"): ?>class="odd"<?php endif; ?> id="<?php echo ($item["id"]); ?>">
					<td><?php echo ($item["id"]); ?></td>
					<td><?php echo ($item["name"]); ?></td>
					<td><?php echo ($item["rules"]); ?></td>
					<td>
						<?php if($item['limit_count'] == -1): ?>不限
						<?php elseif($item['limit_count'] == 0): ?>禁止预约
						<?php else: echo ($item["limit_count"]); endif; ?>
						
					</td>
					<td><?php echo ($item["description"]); ?></td>
					<td>
						<a href="/lark-master/lark-master/index.php/Admin/Device/device_modify/id/<?php echo ($item["id"]); ?>">
							<img src="/lark-master/lark-master/Public/Admin/imgs/edit.png" width="20px" height="20px" alt="修改">
						</a>
					</td>
					<td>
						<a href="/lark-master/lark-master/index.php/Admin/Device/device_delete/id/<?php echo ($item["id"]); ?>">
							<img src="/lark-master/lark-master/Public/Admin/imgs/delete.png" width="20px" height="20px" alt="删除">
						</a>
					</td>
				</tr><?php endforeach; endif; else: echo "" ;endif; ?>
			</tbody>
		</table>
	</div>
</div>
<div class="container">
	<div class="pagesplit" style="colspan:3 bgcolor:#FFF">
		<?php echo ($page); ?>
	</div>
</div>
<!--页脚-->
		<!--页脚-->
	<div class="container">
		<div id="footer">
		    <p title="世博">©2015 <a href="mailto:taoshibopku@126.com">Administrator</a></p>
		</div>
	</div>
</body>
</html>