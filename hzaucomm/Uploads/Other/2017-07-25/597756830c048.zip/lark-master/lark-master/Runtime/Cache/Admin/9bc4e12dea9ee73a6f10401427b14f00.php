<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-theme.min.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap.min.css">
		<!--[if lt IE 9]>
		<script src="/lark-master/lark-master/Public/Common/js/html5shiv.min.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/respond.min.js"></script>
		<![endif]-->
		<script src="/lark-master/lark-master/Public/Common/js/jquery.min.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/bootstrap.min.js"></script>
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Admin/css/style.css">
		<link rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/multiple-select.css" />
		<title><?php echo ($title); ?></title>
	</head>
	<body>
		<br/>
		<br/>
		<!--页眉-->
		<div class="container">
			<div id="header" >
				<h3 class="title" align="center"><?php echo ($title); ?></h3>
			</div>
		</div>
		<!--显示登陆表单-->
		<div class="container">
			<div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
				<div class="panel panel-info" >
					<div class="panel-heading">
						<div class="panel-title">管理员登陆</div>
						<div style="float:right; font-size: 80%; position: relative; top:-10px"><a href="#" style="color:red;">忘记密码?</a></div>
					</div>
					<div style="padding-top:30px" class="panel-body" >
						<div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
						
						<form id="loginform" class="form-horizontal" role="form" action="<?php echo U('Admin/login');?>" method="POST">
							
							<div style="margin-bottom: 25px" class="input-group">
								<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
								<input id="login-username" type="text" class="form-control" name="username" value="" placeholder="用户名">
							</div>
							
							<div style="margin-bottom: 25px" class="input-group">
								<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
								<input id="login-password" type="password" class="form-control" name="passwd" placeholder="密码">
							</div>
							
							<div class="input-group">
								<div class="checkbox">
									<label>
										<input id="login-remember" type="checkbox" name="remember" value="1"> 记住我
									</label>
								</div>
							</div>
							<div style="margin-top:10px" class="form-group">
								<!-- Button -->
								<div class="col-sm-12 controls">
									<button id="btn-login" type="submit" class="btn btn-success">管理员登录</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
				<!--页脚-->
	<div class="container">
		<div id="footer">
		    <p title="世博">©2015 <a href="mailto:taoshibopku@126.com">Administrator</a></p>
		</div>
	</div>
</body>
</html>