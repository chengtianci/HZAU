<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-theme.min.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap.min.css">
		<!--[if lt IE 9]>
	      <script src="/lark-master/lark-master/Public/Common/js/html5shiv.min.js"></script>
	      <script src="/lark-master/lark-master/Public/Common/js/respond.min.js"></script>
	    <![endif]-->
		<script src="/lark-master/lark-master/Public/Common/js/jquery.min.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/bootstrap.min.js"></script>
		<!-- <script src="/lark-master/lark-master/Public/Common/js/bootstrap-wysiwyg.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/jquery.hotkeys.js" type="text/javascript"></script> -->
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Admin/css/style.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/multiple-select.css" />
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/style.css">
		<!-- <link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-combined.no-icons.min.css">
	    <link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-responsive.min.css">
	    <link href="http://netdna.bootstrapcdn.com/font-awesome/3.0.2/css/font-awesome.css" rel="stylesheet"> -->
		<title><?php echo ($title); ?></title>
	</head>
	<body>
<div class="container">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<a href="/lark-master/lark-master"><img src="/lark-master/lark-master/Public/Home/img/logo.png" style="width:200px"></a>
			</div>
			
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
					<li <?php if(($title) == "设备管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Device/device_list');?>">设备管理</a></li>
					<li <?php if(($title) == "添加设备"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Device/device_editor');?>">添加设备</a></li>
					<li <?php if(($title) == "用户管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('User/user_list');?>">用户管理</a></li>
					<li <?php if(($title) == "权限管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Permission/permission_list');?>">权限管理</a></li>
					<li <?php if(($title) == "公告管理"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Bulletin/bulletin_list');?>">公告管理</a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li <?php if(($title) == "设置"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Setting/setting_list');?>">设置</a></li>
					<li><a><?php echo session('valid_user');?></a></li>
					<li><a href="<?php echo U('Admin/logout');?>">退出</a></li>
				</ul>
			</div>
		</div>
	</nav>
</div>
<br/>
<!--显示已经包含的member的列表-->
<div class="container">
	<div class="col-md-8">
		<form action="<?php echo U('Admin/User/user_list');?>" method="get" class="form-horizontal">
			<div class="form-group">
				<div class="col-sm-2">
					<select class="selectpicker form-control" name="type">
						<option value="realname" <?php if(($type) == "realname"): ?>selected<?php endif; ?>>姓名</option>
						<option value="username" <?php if(($type) == "username"): ?>selected<?php endif; ?>>用户名</option>
					</select>
				</div>
				<div class="col-sm-3">
					<input type="text" name="wd" class="form-control" value="<?php echo ($wd); ?>">
				</div>
				<div class="col-sm-1">
					<button type="submit" class="btn btn-primary btn-sm ">查询</button>
				</div>
			</div>
		</form>
	</div>
	<br/>
	<br/>
	<div class="user_list">
		<div class="col-md-12 heading"><?php echo ($title); ?></div>
		<br/>
		<table class="table table-bordered">
			<thead class="table-head">
				<tr>
					<td>用户名</td>
					<td>真实姓名</td>
					<td>邮箱</td>
					<td>手机</td>
					<td>管理员?</td>
					<td>注册时间</td>
					<td>修改</td>
					<td>删除</td>
				</tr>
			</thead>
			<tbody>
				<?php if(is_array($user_list)): $i = 0; $__LIST__ = $user_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><tr <?php if(($mod) == "1"): ?>class="odd"<?php endif; ?>>
					<td><?php echo ($item["username"]); ?></td>
					<td><?php echo ($item["realname"]); ?></td>
					<td><?php echo ($item["email"]); ?></td>
					<td><?php echo ($item["phone"]); ?></td>
					<td><?php if(($item["isadmin"]) == "1"): ?>是<?php else: ?>否<?php endif; ?></td>
					<td><?php echo ($item["createtime"]); ?></td>
					<td>
						<a href="/lark-master/lark-master/index.php/Admin/User/user_modify/username/<?php echo ($item["username"]); ?>">
							<img src="/lark-master/lark-master/Public/Admin/imgs/edit.png" width="20px" height="20px" alt="修改">
						</a>
					</td>
					<td>
						<?php if(($item["username"]) != "admin"): ?><a href="/lark-master/lark-master/index.php/Admin/User/user_delete/username/<?php echo ($item["username"]); ?>">
							<img src="/lark-master/lark-master/Public/Admin/imgs/delete.png" width="20px" height="20px" alt="删除">
						</a><?php endif; ?>
					</td>
				</tr><?php endforeach; endif; else: echo "" ;endif; ?>
			</tbody>
		</table>
	</div>
</div>
<div class="container">
	<div class="pagesplit" style="colspan:3 bgcolor:#FFF">
		<?php echo ($page); ?>
	</div>
</div>
<!--页脚-->
		<!--页脚-->
	<div class="container">
		<div id="footer">
		    <p title="世博">©2015 <a href="mailto:taoshibopku@126.com">Administrator</a></p>
		</div>
	</div>
</body>
</html>