<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-theme.min.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap.min.css">
		<!--[if lt IE 9]>
	      <script src="/lark-master/lark-master/Public/Common/js/html5shiv.min.js"></script>
	      <script src="/lark-master/lark-master/Public/Common/js/respond.min.js"></script>
	    <![endif]-->
		<script src="/lark-master/lark-master/Public/Common/js/jquery.min.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/bootstrap.min.js"></script>
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Home/css/style.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/style.css">
		<link rel="stylesheet" type="text/css" href="/lark-master/lark-master/Public/Home/js/tcal.css" />
		<script type="text/javascript" src="/lark-master/lark-master/Public/Home/js/tcal.js"></script> 
		<title><?php echo ($title); ?></title>
	</head>
	<body>
<div class="container-fluid">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<a href="/lark-master/lark-master"><img src="/lark-master/lark-master/Public/Home/img/logo.png" style="width:200px"></a>
			</div>
			
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
					<li <?php if(($title) == "首页"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/home');?>">首页</a></li>
					<li <?php if(($title) == "预约设备"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/reserve');?>">预约设备</a></li>
					<li <?php if(($title) == "我的预约"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/myReserve');?>">我的预约</a></li>
					<li <?php if(($title) == "联系方式"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Member/contact');?>">联系方式</a></li>
					<li <?php if(($title) == "公告板"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/bulletin');?>">公告板</a></li>
					<li><a href="<?php echo U('Admin/Admin/login');?>">后台管理</a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<?php
 if(!session('valid_user')) { ?>
					<li <?php if(($title) == "新用户注册"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Member/register');?>">注册</a></li>
					<li><a href="<?php echo U('Member/login');?>">登陆</a></li>
					<?php
 }else { ?>
					<li title="个人信息"><a href="<?php echo U('Member/editor');?>"><?php echo session('valid_user');?></a></li>
					<li><a href="<?php echo U('Member/logout');?>">退出</a></li>
					<?php
 } ?>
				</ul>
			</div>
		</div>
	</nav>
</div>
<div class="container-fluid">
	<div class="today_date">
		今天: 
		<?php
 $date=date('Y-m-d'); echo $date.' '.getWeek($date); ?>
	</div>
</div>


	<br/>
	<!--显示修改用户的表单-->
		<div class="container">
			<div class="user_modify">
				<div class="col-md-9 heading col-md-offset-2">
					修改个人信息
				</div>
				<br/>
				<br/>
				<form class="form-horizontal" role="form" method="post" action="<?php echo U('Member/update');?>" onkeydown="if(event.keyCode==13){return false;}">
					<div class="form-group">
					<label for="username" class="col-md-2 control-label">用&nbsp;户&nbsp;名</label>
					<div class="col-md-9">
						<input type="text" class="form-control" id="username" name="username" placeholder="如非必要请勿修改" readonly="readonly" value="<?php echo ($user['username']); ?>">
					</div>
					</div>

					<div class="form-group">
					<label for="passwd" class="col-md-2 control-label">重置密码</label>
					<div class="col-md-9">
						<input type="password" class="form-control" id="passwd" name="passwd" placeholder="new password">
					</div>
					</div>

					<div class="form-group">
					<label for="repasswd" class="col-md-2 control-label">密码确认</label>
					<div class="col-md-9">
						<input type="password" class="form-control" id="repasswd" name="repasswd" placeholder="new password confirm">
					</div>
					</div>

					<div class="form-group">
					<label for="realname" class="col-md-2 control-label">真实姓名</label>
					<div class="col-md-9">
						<input type="text" class="form-control" id="realname" name="realname" placeholder="真实姓名" value="<?php echo ($user['realname']); ?>">
					</div>
					</div>

					<div class="form-group">
					<label for="email" class="col-md-2 control-label">邮&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;箱</label>
					<div class="col-md-9">
						<input type="email" class="form-control" id="email" name="email" placeholder="邮箱" value="<?php echo ($user['email']); ?>">
					</div>
					</div>
					
					<div class="form-group">
					<label for="phone" class="col-md-2 control-label">手&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;机</label>
					<div class="col-md-9">
						<input type="text" class="form-control" id="phone" name="phone" placeholder="联系电话" value="<?php echo ($user['phone']); ?>">
					</div>
					</div>

					<?php if(($user["username"]) != "admin"): ?><div class="form-group">
						<div class=" col-md-offset-2 col-md-10">
							<div class="checkbox">
								<label>
							      <input type="checkbox" name="isadmin" value="1" <?php if(($user["isadmin"]) == "1"): ?>checked<?php endif; ?>> 设为管理员
							    </label>
							</div>
						</div>
					</div><?php endif; ?>
					<br/>
					<div class="form-group">
				    <div class="col-md-offset-2 col-md-10">
				    	<button class="btn btn-primary btn-md col-md-5" name="modify" onclick="javascript:history.back()">取消</button>
				    	<span class="col-md-1"></span>
				      <button type="submit" class="btn btn-success btn-md col-md-5" name="modify">确认修改</button>
				    </div>
				  	</div>

				</form>
			</div>
		</div>
		
		<!--页脚-->
			<!--页脚-->
	<div class="container">
		<div id="footer">
		    <p title="世博">©2015 <a href="mailto:taoshibopku@126.com">Administrator</a></p>
		</div>
	</div>
</body>
</html>