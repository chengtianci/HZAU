<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap-theme.min.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/bootstrap.min.css">
		<!--[if lt IE 9]>
	      <script src="/lark-master/lark-master/Public/Common/js/html5shiv.min.js"></script>
	      <script src="/lark-master/lark-master/Public/Common/js/respond.min.js"></script>
	    <![endif]-->
		<script src="/lark-master/lark-master/Public/Common/js/jquery.min.js"></script>
		<script src="/lark-master/lark-master/Public/Common/js/bootstrap.min.js"></script>
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Home/css/style.css">
		<link type="text/css" rel="stylesheet" href="/lark-master/lark-master/Public/Common/css/style.css">
		<link rel="stylesheet" type="text/css" href="/lark-master/lark-master/Public/Home/js/tcal.css" />
		<script type="text/javascript" src="/lark-master/lark-master/Public/Home/js/tcal.js"></script> 
		<title><?php echo ($title); ?></title>
	</head>
	<body>
<div class="container-fluid">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<a href="/lark-master/lark-master"><img src="/lark-master/lark-master/Public/Home/img/logo.png" style="width:200px"></a>
			</div>
			
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
					<li <?php if(($title) == "首页"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/home');?>">首页</a></li>
					<li <?php if(($title) == "预约设备"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/reserve');?>">预约设备</a></li>
					<li <?php if(($title) == "我的预约"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/myReserve');?>">我的预约</a></li>
					<li <?php if(($title) == "联系方式"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Member/contact');?>">联系方式</a></li>
					<li <?php if(($title) == "公告板"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Reserve/bulletin');?>">公告板</a></li>
					<li><a href="<?php echo U('Admin/Admin/login');?>">后台管理</a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<?php
 if(!session('valid_user')) { ?>
					<li <?php if(($title) == "新用户注册"): ?>class="active"<?php endif; ?>><a href="<?php echo U('Member/register');?>">注册</a></li>
					<li><a href="<?php echo U('Member/login');?>">登陆</a></li>
					<?php
 }else { ?>
					<li title="个人信息"><a href="<?php echo U('Member/editor');?>"><?php echo session('valid_user');?></a></li>
					<li><a href="<?php echo U('Member/logout');?>">退出</a></li>
					<?php
 } ?>
				</ul>
			</div>
		</div>
	</nav>
</div>
<div class="container-fluid">
	<div class="today_date">
		今天: 
		<?php
 $date=date('Y-m-d'); echo $date.' '.getWeek($date); ?>
	</div>
</div>

<script>
//声称保存时间段的二维数组
<?php $num=count($device_list)?>
var num=<?php echo $num;?>;
var period_array=new Array(num+1);
<?php
for($i=0;$i<$num;$i++) { $rules=preg_split('/,\s*/',$device_list[$i]['rules']); $period_string=""; foreach($rules as $time) { $period_string=$period_string.'"'.$time.'"'.','; } $period_string=substr($period_string,0,strlen($period_string)-1); ?>
period_array[<?php echo $device_list[$i]['id'];?>]=new Array(<?php echo $period_string; ?>);
<?php
} ?>
//device改变时触发
function deviceChanged() {
	var select_device=document.reserve_form.select_device;
	//改变defaultselected
	for(var i =0 ;i<select_device.options.length;i++)
	{
		if(select_device.options[i].defaultSelected==true)
		{
			select_device.options[i].defaultSelected=false;
		}
	}
	select_device.options[select_device.selectedIndex].defaultSelected=true;
	updatePeriod();
}
/*
date发生改变时触发
 */
function dateChanged()
{
	var select_date=document.reserve_form.select_date;
	for(var i=0;i<select_date.options.length;i++)
	{
		if(select_date.options[i].defaultSelected==true)
			select_date.options[i].defaultSelected=false;
	}
	select_date.options[select_date.selectedIndex].defaultSelected=true;
}
/*
period发生改变时触发
 */
function periodChanged()
{
	var select_period=document.reserve_form.select_period;
	for(var i=0;i<select_period.options.length;i++)
	{
		if(select_period.options[i].defaultSelected==true)
			select_period.options[i].defaultSelected=false;
	}
	select_period.options[select_period.selectedIndex].defaultSelected=true;
}
/*
根据device类型，设置不同的period option
 */
function updatePeriod()
{
	var select_device=document.reserve_form.select_device;
	//改变period菜单
    var id = select_device.options[select_device.selectedIndex].value;
    var periods=period_array[id];
    var select_period=document.reserve_form.select_period;
    select_period.length = 0;
    select_period.options[0] = new Option('==选择时间段==', '0');
    var selected=false,defaultselected=false;
    for (var i = 0; i < periods.length; i++) {
    	if(i==0){
    		defaultselected=true;
    		selected=true;
    	}else{
    		defaultselected=false;
    		selected=false;}
        select_period.options[select_period.length] = new Option(periods[i], periods[i],defaultselected,selected);
    }
}
window.onload=updatePeriod;
</script>
<div class="container">
    <form id="loginform" class="form-horizontal" name="reserve_form" action="<?php echo U('Reserve/record');?>" method="POST">
        <div class="form-group">
            <div class="col-sm-5">
                <label for="select_device">选择设备</label>
                <select class="form-control" name="select_device" onchange="deviceChanged()">
                    <option value="0">==选择设备==</option>
                    <?php if(is_array($device_list)): $i = 0; $__LIST__ = $device_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><option value="<?php echo ($item["id"]); ?>" <?php if(($item["id"]) == "1"): ?>selected<?php endif; ?>><?php echo ($item["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                </select>
            </div>
            <div class="col-sm-4">
                <label for="select_date">选择日期</label>
                <select class="form-control" name="select_date" onchange="dateChanged()">
                <option selected value="0">==选择日期==</option>
                    <?php if(is_array($date_list)): $i = 0; $__LIST__ = $date_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><option value="<?php echo ($item["date"]); ?>"><?php echo ($item["date"]); ?> &nbsp;&nbsp; <?php echo ($item["week"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                </select>
            </div>
            <div class="col-sm-3">
                <label for="select_period">选择时间段</label>
                <select class="form-control" name="select_period" onchange="periodChanged()">
                    <option selected value="0">==选择时间段==</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <br/>
            <div class="col-sm-12">
                <button type="submit" class="btn btn-primary btn-md btn-block" name="add_user">预约</button>
            </div>
        </div>
    </form>
</div>
		<!--页脚-->
	<div class="container">
		<div id="footer">
		    <p title="世博">©2015 <a href="mailto:taoshibopku@126.com">Administrator</a></p>
		</div>
	</div>
</body>
</html>